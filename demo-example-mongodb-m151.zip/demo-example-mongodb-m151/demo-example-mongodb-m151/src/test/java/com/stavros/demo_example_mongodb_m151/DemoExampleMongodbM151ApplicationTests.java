package com.stavros.demo_example_mongodb_m151;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoExampleMongodbM151ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
