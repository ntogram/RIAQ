package com.stavros.demo_example_mongodb_m151.Model.Support;

public class CrashData {

    private String time;
    private String weathercondition;
    private String lightingcondition;
    private String crashtype;

    public CrashData(String time, String weathercondition, String lightingcondition, String crashtype) {
        this.time = time;
        this.weathercondition = weathercondition;
        this.lightingcondition = lightingcondition;
        this.crashtype = crashtype;
    }

    public CrashData() {
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getWeathercondition() {
        return weathercondition;
    }

    public void setWeathercondition(String weathercondition) {
        this.weathercondition = weathercondition;
    }

    public String getLightingcondition() {
        return lightingcondition;
    }

    public void setLightingcondition(String lightingcondition) {
        this.lightingcondition = lightingcondition;
    }

    public String getCrashtype() {
        return crashtype;
    }

    public void setCrashtype(String crashtype) {
        this.crashtype = crashtype;
    }
}
