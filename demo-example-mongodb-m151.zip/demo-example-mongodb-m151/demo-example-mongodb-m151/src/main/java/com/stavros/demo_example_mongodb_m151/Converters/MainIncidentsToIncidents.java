package com.stavros.demo_example_mongodb_m151.Converters;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;
import com.stavros.demo_example_mongodb_m151.Model.Support.MainIncidents;
import org.springframework.stereotype.Component;

@Component
public class MainIncidentsToIncidents {

    public Incidents convert(MainIncidents mainIncidents) {
        Incidents incidents = new Incidents();
        incidents.setId(mainIncidents.getId());
        incidents.setDate(mainIncidents.getDate());
        incidents.setType(mainIncidents.getType());
        incidents.setZipcode(mainIncidents.getZipcode());
        incidents.setStreetaddress(mainIncidents.getStreetaddress());
        incidents.setWard(mainIncidents.getWard());
        incidents.setLatitude(mainIncidents.getLatitude());
        incidents.setLongitude(mainIncidents.getLongitude());
        return incidents;
    }
}
