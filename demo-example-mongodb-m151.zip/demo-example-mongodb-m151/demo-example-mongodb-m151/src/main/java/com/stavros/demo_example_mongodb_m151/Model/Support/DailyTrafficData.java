package com.stavros.demo_example_mongodb_m151.Model.Support;

public class DailyTrafficData {

    private Integer vehiclenumber;
    private String vehicledirection;

    public DailyTrafficData(Integer vehiclenumber, String vehicledirection) {
        this.vehiclenumber = vehiclenumber;
        this.vehicledirection = vehicledirection;
    }

    public DailyTrafficData() {
    }

    public Integer getVehiclenumber() {
        return vehiclenumber;
    }

    public void setVehiclenumber(Integer vehiclenumber) {
        this.vehiclenumber = vehiclenumber;
    }

    public String getVehicledirection() {
        return vehicledirection;
    }

    public void setVehicledirection(String vehicledirection) {
        this.vehicledirection = vehicledirection;
    }
}
