package com.stavros.demo_example_mongodb_m151.Model.Forms;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;

public class AffordableHousesForm extends Incidents {

    private String communityname;
    private Integer sqfeet;
    private String phonenumber;
    private String managementcompany;

    public AffordableHousesForm(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String communityname, Integer sqfeet, String phonenumber, String managementcompany) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.communityname = communityname;
        this.sqfeet = sqfeet;
        this.phonenumber = phonenumber;
        this.managementcompany = managementcompany;
    }

    public AffordableHousesForm() {
    }

    public String getCommunityname() {
        return communityname;
    }

    public void setCommunityname(String communityname) {
        this.communityname = communityname;
    }

    public Integer getSqfeet() {
        return sqfeet;
    }

    public void setSqfeet(Integer sqfeet) {
        this.sqfeet = sqfeet;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getManagementcompany() {
        return managementcompany;
    }

    public void setManagementcompany(String managementcompany) {
        this.managementcompany = managementcompany;
    }
}
