package com.stavros.demo_example_mongodb_m151.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.stavros.demo_example_mongodb_m151.Model.AffordableHouses;
import com.stavros.demo_example_mongodb_m151.Model.BikeRacks;
import com.stavros.demo_example_mongodb_m151.Model.Crashes;
import com.stavros.demo_example_mongodb_m151.Model.Crimes;
import com.stavros.demo_example_mongodb_m151.Model.DailyTraffic;
import com.stavros.demo_example_mongodb_m151.Model.Incidents;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult2;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult3;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult4;
import com.stavros.demo_example_mongodb_m151.Model.LandInventory;
import com.stavros.demo_example_mongodb_m151.Model.Restaurants;
import com.stavros.demo_example_mongodb_m151.Model.Forms.AffordableHousesForm;

public class QueryRepositoryImpl implements QueryRepository {
	
	@Autowired
	private final MongoTemplate mongoTemplate;
    public QueryRepositoryImpl(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }
	
	
	
	@Override
	public List<InfoResult>group_incidents(String classtype,
			ArrayList<Double> blat, ArrayList<Double> blon) {
		
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		
		
		
		Criteria criteria=Criteria.where("_class").is(classtype)
				.andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon)));
		
		
		
		
		/*criteria=criteria.andOperator(Criteria.where("longitude").lt(maxlon),
			Criteria.where("latitude").gte(minlon))*/
		
		
		
		
		/*Criteria latitudecriteria=Criteria.where("latitude")
		
		Criteria criteria=(new Criteria("_class").is(classtype)).andOperator(new Criteria("latitude").gte((blat.get(0)).doubleValue()),new Criteria("latitude").lte((blat.get(1)).doubleValue()));
		criteria=criteria.andOperator(new Criteria("longitude").gte((blon.get(0)).doubleValue()),new Criteria("longitude").lte((blon.get(1)).doubleValue()));
		*/
		MatchOperation matchoperation=Aggregation.match(criteria);
		GroupOperation groupoperation=Aggregation.group("type").count().as("count");
		SortOperation sortByCount = Aggregation.sort(Direction.DESC, "count");
		Aggregation aggregation=Aggregation.newAggregation(matchoperation,groupoperation,sortByCount);
		AggregationResults<InfoResult> result=mongoTemplate.aggregate(aggregation,Incidents.class, InfoResult.class);
		System.out.println(result);
		List<InfoResult> results= result.getMappedResults();
		//System.out.println(results);
		// TODO Auto-generated method stub
		return results;
	}



	@Override
	public List<InfoResult> group_crimes(ArrayList<Double> blat,
			ArrayList<Double> blon) {
		
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Crimes")
				.andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon)));
		UnwindOperation unwindOperation = Aggregation.unwind("crimeData");
		MatchOperation matchoperation=Aggregation.match(criteria);
		GroupOperation groupoperation=Aggregation.group("crimeData.primarytype").count().as("count");
		SortOperation sortByCount = Aggregation.sort(Direction.DESC, "count");
		Aggregation aggregation=Aggregation.newAggregation(unwindOperation,matchoperation,groupoperation,sortByCount);
		AggregationResults<InfoResult> result=mongoTemplate.aggregate(aggregation,Crimes.class, InfoResult.class);
		System.out.println(result);
		List<InfoResult> results= result.getMappedResults();
		// TODO Auto-generated method stub
		return results;
	}



	@Override
	public List<InfoResult2> group_bikeracks(ArrayList<Double> blat,
			ArrayList<Double> blon) {
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Bike Racks")
				.andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon)));
		MatchOperation matchoperation=Aggregation.match(criteria);
		GroupOperation groupoperation=Aggregation.group("communityname","streetaddress").count().as("count");
		SortOperation sortByCount = Aggregation.sort(Direction.DESC, "count");
		Aggregation aggregation=Aggregation.newAggregation(matchoperation,groupoperation,sortByCount);
		AggregationResults<InfoResult2> result=mongoTemplate.aggregate(aggregation,BikeRacks.class, InfoResult2.class);
		System.out.println(result);
		List<InfoResult2> results= result.getMappedResults();
		// TODO Auto-generated method stub
		return results;
		
		
		
		
		
	
	}



	@Override
	public List<InfoResult3> get_close_restaurants(ArrayList<Double> blat,
			ArrayList<Double> blon) {
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Restaurants")
				.andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon)));
		MatchOperation matchoperation=Aggregation.match(criteria);
		ProjectionOperation projectionoperation= Aggregation.project("restaurantsData.inspectiontype","restaurantsData.results","restaurantsData.violations", "restaurantsData.name", "restaurantsData.facilitytype","streetaddress");
		Aggregation aggregation=Aggregation.newAggregation(matchoperation,projectionoperation);
		AggregationResults<InfoResult3> result=mongoTemplate.aggregate(aggregation,Restaurants.class, InfoResult3.class);
		System.out.println(result);
		List<InfoResult3> results= result.getMappedResults();		
				
		
		
		
		return results;
	}



	@Override
	public List<InfoResult4> get_points_with_more_dailytraffic(
			ArrayList<Double> blat, ArrayList<Double> blon) {
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Average Daily Traffic")
				.andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon)));
		UnwindOperation unwindOperation = Aggregation.unwind("dailyTrafficData");
		MatchOperation matchoperation=Aggregation.match(criteria);
		SortOperation sortByCount = Aggregation.sort(Direction.DESC, "dailyTrafficData.vehiclenumber");
		ProjectionOperation projectionoperation= Aggregation.project("dailyTrafficData.vehiclenumber","streetaddress");
		LimitOperation limitToOnlyFirstDoc = Aggregation.limit(10);
		Aggregation aggregation=Aggregation.newAggregation(unwindOperation,matchoperation,sortByCount,projectionoperation,limitToOnlyFirstDoc);
		AggregationResults<InfoResult4> result=mongoTemplate.aggregate(aggregation,DailyTraffic.class, InfoResult4.class);
		System.out.println(result);
		List<InfoResult4> results= result.getMappedResults();		
				
		
		
		
		return results;
		
	
	}



	@Override
	public List<List<InfoResult>> getcrash_info(ArrayList<Double> blat,
			ArrayList<Double> blon) {
		List<List<InfoResult>> queries_results=new ArrayList<List<InfoResult>>();
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Crashes")
				.andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon)));
		UnwindOperation unwindOperation = Aggregation.unwind("crashData");
		MatchOperation matchoperation=Aggregation.match(criteria);
		GroupOperation groupoperation1=Aggregation.group("crashData.weathercondition").count().as("count");
		GroupOperation groupoperation2=Aggregation.group("crashData.lightingcondition").count().as("count");
		GroupOperation groupoperation3=Aggregation.group("crashData.crashtype").count().as("count");
		SortOperation sortByCount = Aggregation.sort(Direction.DESC, "count");
		
		
		Aggregation aggregation1=Aggregation.newAggregation(unwindOperation,matchoperation,groupoperation1,sortByCount);
		Aggregation aggregation2=Aggregation.newAggregation(unwindOperation,matchoperation,groupoperation2,sortByCount);
		Aggregation aggregation3=Aggregation.newAggregation(unwindOperation,matchoperation,groupoperation3,sortByCount);
		AggregationResults<InfoResult> result1=mongoTemplate.aggregate(aggregation1,Crashes.class, InfoResult.class);
		AggregationResults<InfoResult> result2=mongoTemplate.aggregate(aggregation2,Crashes.class, InfoResult.class);
		AggregationResults<InfoResult> result3=mongoTemplate.aggregate(aggregation3,Crashes.class, InfoResult.class);	
		
		queries_results.add(result1.getMappedResults());
		queries_results.add(result2.getMappedResults());
		queries_results.add(result3.getMappedResults());
		
		
		return queries_results;
	}



	@Override
	public List<LandInventory> get_land(ArrayList<Double> blat,
			ArrayList<Double> blon) {
		Query query = new Query();
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Land Inventory")
				.andOperator(Criteria.where("propertystatus").is("Owned by City").andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon))));
		query.addCriteria(criteria);
		query.fields().include("streetaddress");
		query.fields().include("sqfeet");
		List<LandInventory> results=mongoTemplate.find(query,LandInventory.class);
		for(int i=0;i<results.size();i++){
			if(results.get(i).getSqfeet()==null){
				results.get(i).setSqfeet(-1);
			}
		}
		
		
		return results;
	}



	@Override
	public List<AffordableHouses> get_houses(ArrayList<Double> blat,
			ArrayList<Double> blon, Integer lb, Integer ub) {
		Query query = new Query();
		double minlat=(blat.get(0)).doubleValue();
		double maxlat=(blat.get(1)).doubleValue();
		double minlon=(blon.get(0)).doubleValue();
		double maxlon=(blon.get(1)).doubleValue();
		Criteria criteria=Criteria.where("type").is("Affordable Houses")
				.andOperator(Criteria.where("sqfeet").gte(lb.intValue()).lte(ub.intValue()).andOperator(
					Criteria.where("latitude").gte(minlat).lte(maxlat).andOperator(Criteria.where("longitude").lte( maxlon).gte( minlon))));
		query.addCriteria(criteria);
		/*query.fields().include("communityname");
		query.fields().include("streetaddress");
		query.fields().include("sqfeet");
		query.fields().include("affordableHousesData").include("phonenumber");
		query.fields().include("affordableHousesData").include("managementcompany");
		//query.fields().include("affordableHousesData.phonenumber");
		//query.fields().include("affordableHousesData.managementcompany");*/
		List<AffordableHouses> results=mongoTemplate.find(query,AffordableHouses.class);
		
		
		
		return results;
	}



	@Override
	public List<InfoResult> group_all_incidents_by_zip() {
		GroupOperation groupoperation=Aggregation.group("zipcode").count().as("count");
		SortOperation sortByCount = Aggregation.sort(Direction.DESC, "count");
		LimitOperation limitToOnlyFirstDoc = Aggregation.limit(10);
		Aggregation aggregation=Aggregation.newAggregation(groupoperation,sortByCount,limitToOnlyFirstDoc);
		AggregationResults<InfoResult> result=mongoTemplate.aggregate(aggregation,Incidents.class, InfoResult.class);
		System.out.println(result);
		List<InfoResult> results= result.getMappedResults();		
				
		
		
		
		return results;
		
	}






}
