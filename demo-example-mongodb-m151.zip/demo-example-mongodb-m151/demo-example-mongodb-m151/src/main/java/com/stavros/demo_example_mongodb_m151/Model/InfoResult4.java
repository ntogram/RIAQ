package com.stavros.demo_example_mongodb_m151.Model;

import java.util.List;

public class InfoResult4 {
private String streetaddress;
private int vehiclenumber;
private List<InfoResult4> list;

	public InfoResult4() {
	}

	public String getStreetaddress() {
	return streetaddress;
}
public void setStreetaddress(String streetaddress) {
	this.streetaddress = streetaddress;
}
public int getVehiclenumber() {
	return vehiclenumber;
}
public void setVehiclenumber(int vehiclenumber) {
	this.vehiclenumber = vehiclenumber;
}

	public List<InfoResult4> getList() {
		return list;
	}

	public void setList(List<InfoResult4> list) {
		this.list = list;
	}
}
