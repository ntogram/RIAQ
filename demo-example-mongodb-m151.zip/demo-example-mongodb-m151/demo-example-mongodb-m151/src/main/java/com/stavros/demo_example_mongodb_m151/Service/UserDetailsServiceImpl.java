package com.stavros.demo_example_mongodb_m151.Service;

import com.stavros.demo_example_mongodb_m151.Model.Users.Role;
import com.stavros.demo_example_mongodb_m151.Model.Users.User;
import com.stavros.demo_example_mongodb_m151.Repository.Users.RoleRepository;
import com.stavros.demo_example_mongodb_m151.Repository.Users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public void save(User user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setEnabled(true);
        user.setPasswordConfirm("");
        Role userRole = roleRepository.findByRole("USER");
        user.setRoles(new HashSet<>(Arrays.asList(userRole)));
        userRepository.save(user);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        User user = userRepository.findByEmail(email);
        if (user != null) {
            Set<Role> userRoles = user.getRoles();
            Set<GrantedAuthority> roles = new HashSet<>();
            for (Role r : userRoles) {
                roles.add(new SimpleGrantedAuthority(r.getRole()));
            }
            List<GrantedAuthority> authorityList = new ArrayList<>(roles);
            return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), authorityList);
        } else {
            throw new UsernameNotFoundException("username not found");
        }
    }
}
