package com.stavros.demo_example_mongodb_m151.Model;

import com.stavros.demo_example_mongodb_m151.Model.Support.DailyTrafficData;

public class DailyTraffic extends Incidents {

    private DailyTrafficData dailyTrafficData;

    public DailyTraffic(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, DailyTrafficData dailyTrafficData) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.dailyTrafficData = dailyTrafficData;
    }

    public DailyTraffic() {
    }

    public DailyTrafficData getDailyTrafficData() {
        return dailyTrafficData;
    }

    public void setDailyTrafficData(DailyTrafficData dailyTrafficData) {
        this.dailyTrafficData = dailyTrafficData;
    }
}
