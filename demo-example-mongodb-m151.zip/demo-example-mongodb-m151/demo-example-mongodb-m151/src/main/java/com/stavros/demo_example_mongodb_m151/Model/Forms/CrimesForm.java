package com.stavros.demo_example_mongodb_m151.Model.Forms;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;

public class CrimesForm extends Incidents {
    private String primarytype;
    private String locationdescription;

    public CrimesForm(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String primarytype, String locationdescription) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.primarytype = primarytype;
        this.locationdescription = locationdescription;
    }

    public CrimesForm() {
    }

    public String getPrimarytype() {
        return primarytype;
    }

    public void setPrimarytype(String primarytype) {
        this.primarytype = primarytype;
    }

    public String getLocationdescription() {
        return locationdescription;
    }

    public void setLocationdescription(String locationdescription) {
        this.locationdescription = locationdescription;
    }
}
