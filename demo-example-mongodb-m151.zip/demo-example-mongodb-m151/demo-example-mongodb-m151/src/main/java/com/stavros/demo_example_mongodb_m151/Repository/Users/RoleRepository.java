package com.stavros.demo_example_mongodb_m151.Repository.Users;

import com.stavros.demo_example_mongodb_m151.Model.Users.Role;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RoleRepository extends MongoRepository<Role, String> {
    Role findByRole(String role);
}
