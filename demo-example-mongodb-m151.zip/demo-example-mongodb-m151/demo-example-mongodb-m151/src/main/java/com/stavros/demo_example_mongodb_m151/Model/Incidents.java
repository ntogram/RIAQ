package com.stavros.demo_example_mongodb_m151.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Incidents")
public class Incidents {

    @Id
    private String id;
    private String date;
    private String type;
    private Integer zipcode;
    private String streetaddress;
    private Integer ward;
    private Double latitude;
    private Double longitude;

    public Incidents(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude) {
        this.id = id;
        this.date = date;
        this.type = type;
        this.zipcode = zipcode;
        this.streetaddress = streetaddress;
        this.ward = ward;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Incidents() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getZipcode() {
        return zipcode;
    }

    public void setZipcode(Integer zipcode) {
        this.zipcode = zipcode;
    }

    public String getStreetaddress() {
        return streetaddress;
    }

    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    public Integer getWard() {
        return ward;
    }

    public void setWard(Integer ward) {
        this.ward = ward;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
