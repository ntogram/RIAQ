package com.stavros.demo_example_mongodb_m151.Model.Forms;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;

public class DailyTrafficForm extends Incidents {
    private Integer vehiclenumber;
    private String vehicledirection;

    public DailyTrafficForm(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, Integer vehiclenumber, String vehicledirection) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.vehiclenumber = vehiclenumber;
        this.vehicledirection = vehicledirection;
    }

    public DailyTrafficForm() {
    }

    public Integer getVehiclenumber() {
        return vehiclenumber;
    }

    public void setVehiclenumber(Integer vehiclenumber) {
        this.vehiclenumber = vehiclenumber;
    }

    public String getVehicledirection() {
        return vehicledirection;
    }

    public void setVehicledirection(String vehicledirection) {
        this.vehicledirection = vehicledirection;
    }
}
