package com.stavros.demo_example_mongodb_m151.Model.Support;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;

public class MainIncidents extends Incidents {

    //AffirdableHouses
    private String communityname;
    private Integer sqfeet;
    private AffordableHousesData affordableHousesData;

    //BikeRacks
    //private String communityname;

    //Crashes
    private CrashData crashData;

    //Crimes
    private CrimeData crimeData;

    //DailyTraffic
    private DailyTrafficData dailyTrafficData;

    //LandInventory
    private String propertystatus;
    //private Integer sqfeet;

    //Restaurants
    private RestaurantsData restaurantsData;

    public MainIncidents(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String communityname, Integer sqfeet, AffordableHousesData affordableHousesData, CrashData crashData, CrimeData crimeData, DailyTrafficData dailyTrafficData, String propertystatus, RestaurantsData restaurantsData) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.communityname = communityname;
        this.sqfeet = sqfeet;
        this.affordableHousesData = affordableHousesData;
        this.crashData = crashData;
        this.crimeData = crimeData;
        this.dailyTrafficData = dailyTrafficData;
        this.propertystatus = propertystatus;
        this.restaurantsData = restaurantsData;
    }

    public MainIncidents() {
    }

    public String getCommunityname() {
        return communityname;
    }

    public void setCommunityname(String communityname) {
        this.communityname = communityname;
    }

    public Integer getSqfeet() {
        return sqfeet;
    }

    public void setSqfeet(Integer sqfeet) {
        this.sqfeet = sqfeet;
    }

    public AffordableHousesData getAffordableHousesData() {
        return affordableHousesData;
    }

    public void setAffordableHousesData(AffordableHousesData affordableHousesData) {
        this.affordableHousesData = affordableHousesData;
    }

    public CrashData getCrashData() {
        return crashData;
    }

    public void setCrashData(CrashData crashData) {
        this.crashData = crashData;
    }

    public CrimeData getCrimeData() {
        return crimeData;
    }

    public void setCrimeData(CrimeData crimeData) {
        this.crimeData = crimeData;
    }

    public DailyTrafficData getDailyTrafficData() {
        return dailyTrafficData;
    }

    public void setDailyTrafficData(DailyTrafficData dailyTrafficData) {
        this.dailyTrafficData = dailyTrafficData;
    }

    public String getPropertystatus() {
        return propertystatus;
    }

    public void setPropertystatus(String propertystatus) {
        this.propertystatus = propertystatus;
    }

    public RestaurantsData getRestaurantsData() {
        return restaurantsData;
    }

    public void setRestaurantsData(RestaurantsData restaurantsData) {
        this.restaurantsData = restaurantsData;
    }
}
