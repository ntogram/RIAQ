package com.stavros.demo_example_mongodb_m151.Model.Support;

public class RestaurantsData {

    private String inspectiontype;
    private String results;
    private String violations;
    private String name;
    private String facilitytype;

    public RestaurantsData(String inspectiontype, String results, String violations, String name, String facilitytype) {
        this.inspectiontype = inspectiontype;
        this.results = results;
        this.violations = violations;
        this.name = name;
        this.facilitytype = facilitytype;
    }

    public RestaurantsData() {
    }

    public String getInspectiontype() {
        return inspectiontype;
    }

    public void setInspectiontype(String inspectiontype) {
        this.inspectiontype = inspectiontype;
    }

    public String getResults() {
        return results;
    }

    public void setResults(String results) {
        this.results = results;
    }

    public String getViolations() {
        return violations;
    }

    public void setViolations(String violations) {
        this.violations = violations;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFacilitytype() {
        return facilitytype;
    }

    public void setFacilitytype(String facilitytype) {
        this.facilitytype = facilitytype;
    }
}
