package com.stavros.demo_example_mongodb_m151.Controller;

import com.stavros.demo_example_mongodb_m151.Converters.MainIncidentsToIncidents;
import com.stavros.demo_example_mongodb_m151.Model.*;
import com.stavros.demo_example_mongodb_m151.Model.Support.*;
import com.stavros.demo_example_mongodb_m151.Repository.IncidentsRepository;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.Scanner;

import com.stavros.demo_example_mongodb_m151.geofeatures.OpenStreetMapUtils;
@RestController
@RequestMapping("/rest")
public class RestControllerTemp {

    @Autowired
    private IncidentsRepository incidentsRepository;
    JSONArray obj;
    OpenStreetMapUtils postcode_retriever;
    @Autowired
    private MainIncidentsToIncidents mainIncidentsToIncidents;

    @GetMapping("/find/{id}")
    public Incidents findIncidents(@PathVariable("id") String id) {
        Incidents incidents = incidentsRepository.findByid(id);
        return incidents;
    }

    @PostMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Boolean> insertOrUpdateIncidents(@RequestBody MainIncidents mainIncidents) {
        if (mainIncidents.getType().equals("Service Request")) {
            Incidents incidents = mainIncidentsToIncidents.convert(mainIncidents);
            incidentsRepository.save(incidents);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } else {
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    //DATA INSERTION
   
    @GetMapping("/insertAbandonedVehicles")
    public ResponseEntity<Boolean> InsertAbandonedVehicles() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311AbandonedVehiclesCOL22.csv"));
            while (scanner.hasNext()) {

                //create new object
                Incidents incidents = new Incidents();

                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = parts[4];
                incidents.setType(serviceRequestType);

                //address
                String address = parts[11];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (!(parts[12].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[12]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (!(parts[15].isEmpty() || parts[15].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[15]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 19 && !parts[19].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[19]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[20]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertAlleyLightsOut")
    public ResponseEntity<Boolean> InsertAlleyLightsOut() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311AlleyLightsOutCOL15.csv"));
            while (scanner.hasNext()) {

                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                //String serviceRequestType = parts[4];
                String serviceRequestType = "Street Light Out";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[5];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[6].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[6]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[9].isEmpty() || parts[9].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[9]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 12 && ! parts[12].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[12]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[13]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter ++;
                incidentsRepository.save(incidents);
            }

            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertGarbageCart")
    public ResponseEntity<Boolean> InsertGarbageCart() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311GarbageCartsCOL19.csv"));
            while (scanner.hasNext()) {

                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = parts[4];
                incidents.setType(serviceRequestType);

                //address
                String address = parts[8];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[9].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[9]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[12].isEmpty() || parts[12].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[12]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 16 && ! parts[16].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[16]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[17]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertGraffitiRemoval")
    public ResponseEntity<Boolean> InsertGraffitiRemoval() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311GraffitiRemovalCOL18.csv"));
            while (scanner.hasNext()) {
                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = parts[4];
                incidents.setType(serviceRequestType);

                //address
                String address = parts[7];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[8].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[8]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[11].isEmpty() || parts[11].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[11]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 15 && ! parts[15].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[15]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[16]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }

                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertPotHoles")
    public ResponseEntity<Boolean> InsertPotHoles() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311PotHolesCOL19.csv"));
            while (scanner.hasNext()) {
                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = "Pothole in Street";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[7];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[9].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[9]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[12].isEmpty() || parts[12].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[12]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 16 && ! parts[16].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[16]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[17]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertRodentBaiting")
    public ResponseEntity<Boolean> InsertRodentBaiting() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311RodentBaitingCOL20.csv"));
            while (scanner.hasNext()) {

                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = parts[4];
                incidents.setType(serviceRequestType);

                //address
                String address = parts[10];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[11].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[11]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[14].isEmpty() || parts[14].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[14]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 17 && ! parts[17].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[17]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[18]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertSanitationCode")
    public ResponseEntity<Boolean> InsertSanitationCode() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311SanitationCodeCOL16.csv"));
            while (scanner.hasNext()) {

                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = "Sanitation Code Violation";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[6];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[7].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[7]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[10].isEmpty() || parts[10].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[10]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 13 && ! parts[13].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[13]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[14]);
                    incidents.setLongitude(longitude);
                }

                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertStreetLightsAllOut")
    public ResponseEntity<Boolean> InsertStreetLightsAllOut() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311StreetLightsAllOutCOL15.csv"));
            while (scanner.hasNext()) {

                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                //String serviceRequestType = parts[4];
                String serviceRequestType = "Street Light Out";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[5];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }


                if (! (parts[6].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[6]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[9].isEmpty() || parts[9].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[9]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 12 && ! parts[12].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[12]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[13]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertStreetLightsOneOut")
    public ResponseEntity<Boolean> InsertStreetLightsOneOut() {
        try {

            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311StreetLightsOneOutCOL15.csv"));
            while (scanner.hasNext()) {
                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = "Street Light Out";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[5];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[6].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[6]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[9].isEmpty() || parts[9].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[9]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 12 && ! parts[12].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[12]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[13]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }

                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertTreeDebris")
    public ResponseEntity<Boolean> InsertTreeDebris() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311TreeDebrisCOL18.csv"));
            while (scanner.hasNext()) {
                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = "Tree Trim";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[8];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[9].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[9]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[12].isEmpty() || parts[12].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[12]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 15 && ! parts[15].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[15]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[16]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }
                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertTreeTrims")
    public ResponseEntity<Boolean> InsertTreeTrims() {
        try {
            String line;
            int counter = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/chicago-311-service-requests/311TreeTrimsCOL16.csv"));
            while (scanner.hasNext()) {
                Incidents incidents = new Incidents();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String[] tempString = parts[0].split("T");
                String data = tempString[0];
                incidents.setDate(data);

                //service request type
                String serviceRequestType = "Tree Trim";
                incidents.setType(serviceRequestType);

                //address
                String address = parts[6];
                if (address.isEmpty()) {
                    incidents.setStreetaddress("");
                } else {
                    incidents.setStreetaddress(address);
                }

                if (! (parts[7].isEmpty())) {
                    //zipcode
                    Integer zipcode = Integer.parseInt(parts[7]);
                    incidents.setZipcode(zipcode);
                } else {
                    incidents.setZipcode(null);
                }

                if (! (parts[10].isEmpty() || parts[10].compareTo(" ") == 0)) {
                    //ward
                    Integer ward = Integer.parseInt(parts[10]);
                    incidents.setWard(ward);
                } else {
                    incidents.setWard(null);
                }

                if (parts.length > 13 && ! parts[13].isEmpty()) {
                    //latitude
                    Double latitude = Double.parseDouble(parts[13]);
                    incidents.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[14]);
                    incidents.setLongitude(longitude);
                } else {
                    incidents.setLatitude(null);
                    incidents.setLongitude(null);
                }

                counter ++;
                incidentsRepository.save(incidents);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertAffordableHouses")
    public ResponseEntity<Boolean> InsertAffordableHouses()  {
        try {
            String line;
            int counter = 0; int nullLatitude = 0; int nullLongitude = 0; int nullCommunityName = 0; int nullAddress = 0; int nullZipcode = 0; int nullPhoneNumber = 0; int nullManagementCompany = 0; int nullUnits = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/affordable-rental-housing-developments.csv"));
            while (scanner.hasNext()) {
                AffordableHouses affordableHouses = new AffordableHouses();
                AffordableHousesData affordableHousesData = new AffordableHousesData();

                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //community name
                if (parts[0].isEmpty() || parts[0].compareTo(" ") == 0) {
                    nullCommunityName ++;
                    affordableHouses.setCommunityname("");
                } else {
                    String communityName = parts[0];
                    affordableHouses.setCommunityname(communityName);
                }

                //address
                if (parts[4].isEmpty() || parts[4].compareTo(" ") == 0) {
                    nullAddress ++;
                    affordableHouses.setStreetaddress("");
                } else {
                    String address = parts[4];
                    affordableHouses.setStreetaddress(address);
                }

                //zipcode
                if (parts[5].isEmpty() || parts[5].compareTo(" ") == 0) {
                    nullZipcode ++;
                    affordableHouses.setZipcode(null);
                } else {
                    Integer zipcode = Integer.parseInt(parts[5]);
                    affordableHouses.setZipcode(zipcode);
                }

                //phone number
                if (parts[6].isEmpty() || parts[6].compareTo(" ") == 0) {
                    nullPhoneNumber ++;
                    affordableHousesData.setPhonenumber("");
                } else {
                    String phoneNumber = parts[6];
                    affordableHousesData.setPhonenumber(phoneNumber);
                }

                //management company
                if (parts[7].isEmpty() || parts[7].compareTo(" ") == 0) {
                    nullManagementCompany ++;
                    affordableHousesData.setManagementcompany("");
                } else {
                    String managementCompany = parts[7];
                    affordableHousesData.setManagementcompany(managementCompany);
                }

                //units
                if (parts[8].isEmpty() || parts[8].compareTo(" ") == 0) {
                    nullUnits ++;
                    affordableHouses.setSqfeet(null);
                } else {
                    Integer units = Integer.parseInt(parts[8]);
                    affordableHouses.setSqfeet(units);
                }

                if (parts.length > 11) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[11]);
                    affordableHouses.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[12]);
                    affordableHouses.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    nullLongitude ++;
                    affordableHouses.setLatitude(null);
                    affordableHouses.setLongitude(null);
                }
                counter ++;
                affordableHouses.setType("Affordable Houses");
                affordableHouses.setAffordableHousesData(affordableHousesData);
                incidentsRepository.save(affordableHouses);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertBikeRacks")
    public ResponseEntity<Boolean> InsertBikeRacks() {
        try {
            String line;
            int counter = 0; int nullLatitude = 0; int nullLongitude = 0; int nullAddress = 0; int nullWard = 0; int nullCommunityName = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/bike-racks.csv"));
            while (scanner.hasNext()) {
                BikeRacks bikeRacks = new BikeRacks();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //address
                if (parts[1].isEmpty() || parts[1].compareTo(" ") == 0) {
                    nullAddress ++;
                    bikeRacks.setStreetaddress("");
                } else {
                    String address = parts[1];
                    bikeRacks.setStreetaddress(address);
                }

                //ward
                if (parts[2].isEmpty() || parts[2].compareTo(" ") == 0) {
                    nullWard ++;
                    bikeRacks.setWard(null);
                } else {
                    Integer ward = Integer.parseInt(parts[2]);
                    bikeRacks.setWard(ward);
                }

                //community name
                if (parts[4].isEmpty() || parts[4].compareTo(" ") == 0) {
                    nullCommunityName ++;
                    bikeRacks.setCommunityname("");
                } else {
                    String communityName = parts[4];
                    bikeRacks.setCommunityname(communityName);
                }

                if (parts.length > 6) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[6]);
                    bikeRacks.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[7]);
                    bikeRacks.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    bikeRacks.setLatitude(null);
                    nullLongitude ++;
                    bikeRacks.setLongitude(null);
                }
                counter ++;
                bikeRacks.setType("Bike Racks");
                incidentsRepository.save(bikeRacks);
            }

            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertCrashes")
    public ResponseEntity<Boolean> InsertCrashes() {
        try {
            String line;
            int counter = 0; int nullDate = 0; int nullWeatherCondition = 0; int nullLightingCondition = 0; int nullCrashType = 0; int nullStreetName = 0; int nullLatitude = 0; int nullLongitude = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/Traffic_Crashes_-_Crashes.csv"));
            while (scanner.hasNext()) {
                Crashes crashes = new Crashes();
                CrashData crashData = new CrashData();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date and time
                String year = ""; year += parts[2].charAt(6); year += parts[2].charAt(7); year += parts[2].charAt(8); year += parts[2].charAt(9);
                String month = ""; month += parts[2].charAt(0); month += parts[2].charAt(1);
                String day = ""; day += parts[2].charAt(3); day += parts[2].charAt(4);
                String date = year+"-"+month+"-"+day;
                String time = "";
                for (int i=11; i<22; i++) {
                    time += parts[2].charAt(i);
                }
                crashData.setTime(time);
                crashes.setDate(date);
                if (date.equals(null)) {
                    nullDate ++;
                    crashes.setDate("");
                }

                //weather condition
                if (parts[6].isEmpty() || parts[6].compareTo(" ") == 0) {
                    nullWeatherCondition ++;
                    crashData.setWeathercondition("");
                } else {
                    String weatherCondition = parts[6];
                    crashData.setWeathercondition(weatherCondition);
                }

                //lighting condition
                if (parts[7].isEmpty() || parts[7].compareTo(" ") == 0) {
                    nullLightingCondition ++;
                    crashData.setLightingcondition("");
                } else {
                    String lightingCondition = parts[7];
                    crashData.setLightingcondition(lightingCondition);
                }

                //crash type
                if (parts[15].isEmpty() || parts[15].compareTo(" ") == 0) {
                    nullCrashType ++;
                    crashData.setCrashtype("");
                } else {
                    String crashType = parts[15];
                    crashData.setCrashtype(crashType);
                }

                //street name
                if (parts[25].isEmpty() || parts[25].compareTo(" ") == 0) {
                    nullStreetName ++;
                    crashes.setStreetaddress("");
                } else {
                    String streetName = parts[24];
                    streetName += " "+parts[25];
                    streetName += " "+parts[26];
                    crashes.setStreetaddress(streetName);
                }

                if (parts.length > 45) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[45]);
                    crashes.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[46]);
                    crashes.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    crashes.setLatitude(null);
                    nullLongitude ++;
                    crashes.setLongitude(null);
                }
                counter ++;
                crashes.setType("Crashes");
                crashes.setCrashData(crashData);
                incidentsRepository.save(crashes);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertCrimes")
    public ResponseEntity<Boolean> InsertCrimes() {
        try {
            String line;
            int counter = 0; int nullDate = 0; int nullBlocks = 0; int nullPrimaryType = 0; int nullLocationDescription = 0; int nullWard = 0; int nullLatitude = 0; int nullLongitude = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/Chicago_Crimes_2012_to_2017.csv"));
            while (scanner.hasNext()) {
                Crimes crimes = new Crimes();
                CrimeData crimeData = new CrimeData();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String year = ""; year += parts[3].charAt(6); year += parts[3].charAt(7); year += parts[3].charAt(8); year += parts[3].charAt(9);
                String month = ""; month += parts[3].charAt(0); month += parts[3].charAt(1);
                String day = ""; day += parts[3].charAt(3); day += parts[3].charAt(4);
                String date = year+"-"+month+"-"+day;

                crimes.setDate(date);
                if (date.equals(null)) {
                    nullDate ++;
                    crimes.setDate("");
                }

                //blocks
                String blocks = parts[4];

                if (blocks.isEmpty() || blocks.compareTo(" ") == 0) {
                    nullBlocks ++;
                }

                //primary type
                String primaryType = parts[6];
                crimeData.setPrimarytype(primaryType);

                if (primaryType.isEmpty() || primaryType.compareTo(" ") == 0) {
                    nullBlocks ++;
                    crimeData.setPrimarytype("");
                }

                //location description
                String locationDescription = parts[8];
                crimeData.setLocationdescription(locationDescription);

                if (locationDescription.isEmpty() || locationDescription.compareTo(" ") == 0) {
                    nullLocationDescription ++;
                    crimeData.setLocationdescription("");
                }

                //ward
                if (! parts[13].isEmpty()) {

                    String[] subParts = parts[13].split("\\.");
                    Integer ward = Integer.parseInt(subParts[0]);
                    crimes.setWard(ward);

                } else {
                    nullWard ++;
                    crimes.setWard(null);
                }

                if (parts.length > 20) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[20]);
                    crimes.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[21]);
                    crimes.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    crimes.setLatitude(null);
                    nullLongitude ++;
                    crimes.setLongitude(null);
                }
                counter ++;
                crimes.setType("Crimes");
                crimes.setCrimeData(crimeData);
                incidentsRepository.save(crimes);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertRestaurants")
    public ResponseEntity<Boolean> InsertRestaurants() {
        try {
            String line;
            int counter = 0; int nullDate = 0; int nullInspectionType = 0; int nullResults = 0; int nullViolations = 0; int nullLatitude = 0; int nullLongitude = 0; int nullName = 0; int nullFacilityType = 0; int nullAddress = 0; int nullCity = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/food-inspections.csv"));
            while (scanner.hasNext()) {
                Restaurants restaurants = new Restaurants();
                RestaurantsData restaurantsData = new RestaurantsData();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //date
                String year = ""; year += parts[10].charAt(0); year += parts[10].charAt(1); year += parts[10].charAt(2); year += parts[10].charAt(3);
                String month = ""; month += parts[10].charAt(5); month += parts[10].charAt(6);
                String day = ""; day += parts[10].charAt(8); day += parts[10].charAt(9);
                String date = year+"-"+month+"-"+day;

                restaurants.setDate(date);
                if (date.equals(null)) {
                    nullDate ++;
                    restaurants.setDate("");
                }

                //inspection type
                if (parts[11].isEmpty() || parts[11].compareTo(" ") == 0) {
                    nullInspectionType ++;
                    restaurantsData.setInspectiontype("");
                } else {
                    String inspectionType = parts[11];
                    restaurantsData.setInspectiontype(inspectionType);
                }

                //results
                if (parts[12].isEmpty() || parts[12].compareTo(" ") == 0) {
                    nullResults ++;
                    restaurantsData.setResults("");
                } else {
                    String results = parts[12];
                    restaurantsData.setResults(results);
                }

                if (parts.length > 13) {
                    //violations
                    if (parts[13].isEmpty() || parts[13].compareTo(" ") == 0) {
                        nullViolations ++;
                        restaurantsData.setViolations("");
                    } else {
                        String violations = parts[13];
                        restaurantsData.setViolations(violations);
                    }
                } else {
                    nullViolations ++;
                    restaurantsData.setViolations("");
                }

                if (parts.length > 14) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[14]);
                    restaurants.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[15]);
                    restaurants.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    restaurants.setLatitude(null);
                    nullLongitude ++;
                    restaurants.setLongitude(null);
                }

                //name
                if (parts[2].isEmpty() || parts[2].compareTo(" ") == 0) {
                    nullName ++;
                    restaurantsData.setName("");
                } else {
                    String name = parts[2];
                    restaurantsData.setName(name);
                }

                //facilityType
                if (parts[4].isEmpty() || parts[4].compareTo(" ") == 0) {
                    nullFacilityType ++;
                    restaurantsData.setFacilitytype("");
                } else {
                    String facilityType = parts[4];
                    restaurantsData.setFacilitytype(facilityType);
                }

                //address
                if (parts[6].isEmpty() || parts[6].compareTo(" ") == 0) {
                    nullAddress ++;
                    restaurants.setStreetaddress("");
                } else {
                    String address = parts[6];
                    restaurants.setStreetaddress(address);
                }

                //city
                if (parts[7].isEmpty() || parts[7].compareTo(" ") == 0) {
                    nullCity ++;
                } else {
                    String city = parts[7];
                }
                counter++;
                restaurants.setType("Restaurants");
                restaurants.setRestaurantsData(restaurantsData);
                incidentsRepository.save(restaurants);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertDailyTraffic")
    public ResponseEntity<Boolean> InsertDailyTraffic() {
        try {
            String line;
            int counter = 0; int nullLatitude = 0; int nullLongitude = 0; int nullAddress = 0; int nullStreet = 0; int nullTotalVehicles = 0; int nullVehicleDirection = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/average-daily-traffic-counts.csv"));
            while (scanner.hasNext()) {
                DailyTraffic dailyTraffic = new DailyTraffic();
                DailyTrafficData dailyTrafficData = new DailyTrafficData();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //address and address
                if (parts[1].isEmpty() || parts[1].compareTo(" ") == 0) {
                    nullAddress ++;
                    dailyTraffic.setStreetaddress("");
                } else {
                    String address = parts[1] + " " + parts[2];
                    dailyTraffic.setStreetaddress(address);
                }

                //total vehicles
                if (parts[4].isEmpty() || parts[4].compareTo(" ") == 0) {
                    nullTotalVehicles ++;
                    dailyTrafficData.setVehiclenumber(null);
                } else {
                    Integer totalVehicles = Integer.parseInt(parts[4]);
                    dailyTrafficData.setVehiclenumber(totalVehicles);
                }

                //vehicle direction
                if (parts[5].isEmpty() || parts[5].compareTo(" ") == 0) {
                    nullVehicleDirection ++;
                    dailyTrafficData.setVehicledirection("");
                } else {
                    String vehicleDirection = parts[5];
                    dailyTrafficData.setVehicledirection(vehicleDirection);
                }

                if (parts.length > 6) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[6]);
                    dailyTraffic.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[7]);
                    dailyTraffic.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    dailyTraffic.setLatitude(null);
                    nullLongitude ++;
                    dailyTraffic.setLongitude(null);
                }

                counter ++;
                dailyTraffic.setType("Average Daily Traffic");
                dailyTraffic.setDailyTrafficData(dailyTrafficData);
                incidentsRepository.save(dailyTraffic);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/insertLandInventory")
    public ResponseEntity<Boolean> InsertLandInventory() {
        try {
            String line;
            int counter = 0; int nullLatitude = 0; int nullLongitude = 0; int nullAddress = 0; int nullPropertyStatus = 0; int nullSqFeet = 0; int nullWard = 0; int nullZipcode = 0;
            Scanner scanner = new Scanner(new File("C:/Users/Alexandros_Fotios/Downloads/M151_Project_Datasets-temp/M151_Project_Datasets-temp/city-owned-land-inventory.csv"));
            while (scanner.hasNext()) {
                LandInventory landInventory = new LandInventory();
                //Get next line
                line = scanner.nextLine();

                //Split string with regex
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                //address
                if (parts[2].isEmpty() || parts[2].compareTo(" ") == 0) {
                    nullAddress ++;
                    landInventory.setStreetaddress("");
                } else {
                    String address = parts[2];
                    landInventory.setStreetaddress(address);
                }

                //property status
                if (parts[4].isEmpty() || parts[4].compareTo(" ") == 0) {
                    nullPropertyStatus ++;
                    landInventory.setPropertystatus("");
                } else {
                    String propertyStatus = parts[4];
                    landInventory.setPropertystatus(propertyStatus);
                }

                //sq feet
                if (parts[7].isEmpty() || parts[7].compareTo(" ") == 0 || parts[7].compareTo("0") == 0) {
                    nullSqFeet ++;
                    landInventory.setSqfeet(null);
                } else {
                    Integer sqFeet = Integer.parseInt(parts[7]);
                    landInventory.setSqfeet(sqFeet);
                }

                //ward
                if (parts[8].isEmpty() || parts[8].compareTo(" ") == 0) {
                    nullWard ++;
                    landInventory.setWard(null);
                } else {
                    Integer ward = Integer.parseInt(parts[8]);
                    landInventory.setWard(ward);
                }

                //zipcode
                if (parts[12].isEmpty() || parts[12].compareTo(" ") == 0) {
                    nullZipcode ++;
                    landInventory.setZipcode(null);
                } else {
                    Integer zipcode = Integer.parseInt(parts[12]);
                    landInventory.setZipcode(zipcode);
                }

                if (parts.length > 16) {

                    //latitude
                    Double latitude = Double.parseDouble(parts[16]);
                    landInventory.setLatitude(latitude);

                    //longitude
                    Double longitude = Double.parseDouble(parts[17]);
                    landInventory.setLongitude(longitude);

                } else {
                    nullLatitude ++;
                    landInventory.setLatitude(null);
                    nullLongitude ++;
                    landInventory.setLongitude(null);
                }

                counter ++;
                landInventory.setType("Land Inventory");
                incidentsRepository.save(landInventory);
            }
            System.out.println("lines: "+counter);
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
        }
    }
    
}
