package com.stavros.demo_example_mongodb_m151.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.stavros.demo_example_mongodb_m151.Config.AuthenticationFacade;
import com.stavros.demo_example_mongodb_m151.Converters.ModelToObject;
import com.stavros.demo_example_mongodb_m151.Model.*;
import com.stavros.demo_example_mongodb_m151.Model.Forms.*;
import com.stavros.demo_example_mongodb_m151.Model.Users.User;
import com.stavros.demo_example_mongodb_m151.Repository.IncidentsRepository;
import com.stavros.demo_example_mongodb_m151.Repository.QueryRepositoryImpl;
import com.stavros.demo_example_mongodb_m151.Repository.Users.UserRepository;
import com.stavros.demo_example_mongodb_m151.Service.UserDetailsServiceImpl;
import com.stavros.demo_example_mongodb_m151.geofeatures.OpenStreetMapUtils;

import org.apache.log4j.BasicConfigurator;
import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

@Controller
public class WebController {

    private final double bounding_factor=0.01;//need reconfiguration

    @Autowired
	protected AuthenticationManager authenticationManager;
	
	@Autowired
	private AuthenticationFacade authenticationFacade;

	@Autowired
    private UserRepository userRepository;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @Autowired
    private IncidentsRepository incidentsRepository;
    
    @Autowired
    private MongoTemplate mongoTemplate;

    ModelToObject modelToObject = new ModelToObject();

    @Autowired
    private OpenStreetMapUtils address_retriever;

    @GetMapping(value="/chat/index")
    public String chat(@RequestParam(name = "fullname", required = false, defaultValue = "") 
	String fullname , Model model){
    	
    	Authentication authentication = authenticationFacade.getAuthentication();
    	User user = userRepository.findByEmail(authentication.getName());
    	fullname=user.getFullname();
    	System.out.println(user.getFullname());
    	
    	 model.addAttribute("fullname", fullname);  
    	return "chat/index";
    }

    @GetMapping(value = "/register")
    public String register(Model model) {
        model.addAttribute("registerform", new User());
        return "users/register";
    }
    
    @PostMapping(value = "/register")
    public String register(@ModelAttribute User user, Model model, HttpServletRequest request) {
        boolean legit = true;
        if (userRepository.findByEmail(user.getEmail()) != null) {
            user.setEmail(null);
            legit = false;
        }
        if (!user.getPassword().equals(user.getPasswordConfirm())) {
            user.setPassword(null);
            user.setPasswordConfirm(null);
            legit = false;
        }
        if (legit) {
            userDetailsServiceImpl.save(user);
           // authWithAuthManager(request,user.getEmail(),user.getPassword());
            return "redirect:/";
        } else {
            model.addAttribute("registerform", user);
            return "users/register";
        }
    }
    
    public void authWithAuthManager(HttpServletRequest request, String email, String password) {
        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(email, password);
        authToken.setDetails(new WebAuthenticationDetails(request));
        Authentication authentication = authenticationManager.authenticate(authToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }
    @GetMapping(value="/index/zip")
    public String group_zip(Model model){
    	QueryRepositoryImpl qri=new QueryRepositoryImpl(mongoTemplate);
    	List<InfoResult> results;
    	results=qri.group_all_incidents_by_zip();
		 model.addAttribute(qri);
		//System.out.println(results.size());
		 //for(int i=0;i<results.size();i++){
		 //	 System.out.println((results.get(i)).getName()+"\t"+(results.get(i)).getCount());
		// }
		 InfoResult zipResult = new InfoResult();
		 zipResult.setList(results);
		 model.addAttribute("zipresult", zipResult);
    	return "zip";
    }
    
    @GetMapping(value="/index/search")
    public String search(Model model){
    	model.addAttribute("searchform", new SearchForm());
    	return "searchform";
    }
    
    @PostMapping("/index/search")
    public String get_results(@ModelAttribute SearchForm searchform, Model model){
    	JSONArray obj;
    	ArrayList<String> available_addresses=new ArrayList<String>();
        BasicConfigurator.configure();
        //OpenStreetMapUtils address_retriever=new  OpenStreetMapUtils();
        obj=address_retriever.getAddressobj(searchform.getAddress());
        available_addresses=address_retriever.SelectRegion(obj);
        searchform.setAvailable_addresses(available_addresses);
    	model.addAttribute("searchform", searchform);
    	
    	
    	if(available_addresses.size()>1){
    	return "preresults";}
    	else{
    		Map<String, Double> coords;
    		coords = address_retriever.getCoordinates(obj,0);
    		double lat=(coords.get("lat"));
    	    double lon=(coords.get("lon"));
    	    ArrayList<Double> blat=new ArrayList<Double>();
    	    ArrayList<Double> blon=new ArrayList<Double>();
    	    blat.add(lat-bounding_factor);
    		blat.add(lat+bounding_factor);
    		blon.add(lon-bounding_factor);
    		blon.add(lon+bounding_factor);
    		/*Map<String, Double> bcoords;
    		bcoords=address_retriever.getBoundingbox(obj,0);
    		ArrayList<Double> blat=new ArrayList<Double>();
    		blat.add(bcoords.get(new String("0")));
    		blat.add(bcoords.get(new String("1")));
    		ArrayList<Double> blon=new ArrayList<Double>();
    		blon.add(bcoords.get(new String("2")));
    		blon.add(bcoords.get(new String("3")));*/
    		 Collections.sort(blat);
    		 Collections.sort(blon);
    		 System.out.println(blat);
    		 System.out.println(blon);
    		 String type=searchform.get_correct_type();
    		 QueryRepositoryImpl qri=new QueryRepositoryImpl(mongoTemplate);
    		 List<InfoResult> results;
    		 switch(type){
    		 case "Incidents":
    			 results=qri.group_incidents("com.stavros.demo_example_mongodb_m151.Model.Incidents", blat, blon);
    			 model.addAttribute(qri);
    			//System.out.println(results.size());
    			 //for(int i=0;i<results.size();i++){
    			 //	 System.out.println((results.get(i)).getName()+"\t"+(results.get(i)).getCount());
    			// }
    			 InfoResult infoResult = new InfoResult();
    			 infoResult.setList(results);
    			 model.addAttribute("inforesult", infoResult);
    			 //return "results/inforesult";
    			 	break;
                case "Crimes":
                    results=qri.group_crimes( blat, blon);
                    model.addAttribute(qri);
                    System.out.println(results.size());
                    InfoResult infoResult1b = new InfoResult();
                    infoResult1b.setList(results);
                    model.addAttribute("inforesult", infoResult1b);
                    //return "results/inforesult";
                    break;
                case "Bike Racks":
                    List<InfoResult2> results2;
                    results2=qri.group_bikeracks(blat, blon);
                    model.addAttribute(qri);
                    System.out.println(results2.size());
//                    int i1;
//                    for(int i=0;i<results2.size();i++){
//                        System.out.println("{"+(results2.get(i)).getCommunityname()+","+(results2.get(i)).getStreetaddress()+"\t"+(results2.get(i)).getCount());
//                    }
                    InfoResult2 infoResult2 = new InfoResult2();
                    infoResult2.setList(results2);
                    model.addAttribute("inforesult2", infoResult2);
                   //return "results/inforesult2";
                    break;
    		 case "Restaurants":
    			 List<InfoResult3> results3;
    			 results3=qri.get_close_restaurants(blat, blon);
    			System.out.println(results3.size());
//    			Scanner input = new Scanner(System.in);
//    			 for(int i=0;i<results3.size();i++){
//
//    				 System.out.println((results3.get(i)).getInspectiontype());
//    				 System.out.println((results3.get(i)).getResults());
//    				 System.out.println((results3.get(i)).getName());
//    				 System.out.println((results3.get(i)).getFacilitytype());
//    				 System.out.println((results3.get(i)).getStreetaddress());
//    				 int p = input.nextInt();
//    				 if(p==0){
//    					 break;
//    				 }
//
//
//
//    		 }
                InfoResult3 infoResult3 = new InfoResult3();
                infoResult3.setList(results3);
                 model.addAttribute("inforesult3", infoResult3);
                // return "results/inforesult3";
    		    break;
    		 case "Daily Traffic":
    			 List<InfoResult4> results4;
   			  results4=qri.get_points_with_more_dailytraffic(blat, blon);
   			 model.addAttribute(qri);
   			System.out.println(results4.size());
//   			 for(int i=0;i<results4.size();i++){
//   				 System.out.println((results4.get(i)).getStreetaddress()+"\t"+(results4.get(i)).getVehiclenumber());
//
//   		 }
                 InfoResult4 infoResult4 = new InfoResult4();
                 infoResult4.setList(results4);
                 model.addAttribute("inforesult4", infoResult4);
                 //return "results/inforesult4";
                 break;
    		 case "Crashes":
    			 /*Scanner input1 = new Scanner(System.in);*/
    			 List<List<InfoResult>> queries_results=qri.getcrash_info(blat, blon);
    			 model.addAttribute(qri);
    			 InfoResult infoResultc1 = new InfoResult();
    			 infoResultc1.setList(queries_results.get(0));
    			 model.addAttribute("inforesultc1", infoResultc1);
    			 InfoResult infoResultc2 = new InfoResult();
    			 infoResultc2.setList(queries_results.get(1));
    			 model.addAttribute("inforesultc2", infoResultc2);
    			 InfoResult infoResultc3 = new InfoResult();
    			 infoResultc3.setList(queries_results.get(2));
    			 model.addAttribute("inforesultc3", infoResultc3);
    			 
    			 
    			/* model.addAttribute("inforesultc1", queries_results.get(0));
    			 model.addAttribute("inforesultc2", queries_results.get(1));
    			 model.addAttribute("inforesultc3", queries_results.get(2));*/
    			 //System.out.println("end here");*/
    			 break;
    		 case "Land Inventory":
    			 List<LandInventory> land_results=qri.get_land(blat, blon);
    			 System.out.println(land_results.size());
//    			 for(int i=0;i<21;i++){
//    				// System.out.println((land_results.get(i)).getStreetaddress());
//       				 System.out.println((land_results.get(i)).getStreetaddress()+"\t"+(land_results.get(i)).getSqfeet());
//
//       		 }
                 model.addAttribute("list", land_results);
                 //return ("results/landinventory");
    			 break;
    		 case  "Affordable Houses":
    			 //Scanner input2 = new Scanner(System.in);
    			 Integer lower_bound=new Integer((searchform.getBottom_area_bound()));
    			 Integer upper_bound=new Integer((searchform.getUpper_area_bound()));
    			 List<AffordableHouses> houses_results=qri.get_houses(blat, blon, lower_bound, upper_bound);
    			 System.out.println("LEN:"+houses_results.size());
   			/* for(int i=0;i<21;i++){
   				 AffordableHouses r1=houses_results.get(i);
   					System.out.println(r1.getCommunityname());
   					System.out.println(r1.getStreetaddress());
   					System.out.println(r1.getSqfeet());
    					System.out.println((r1.getAffordableHousesData()).getManagementcompany());
    					System.out.println((r1.getAffordableHousesData()).getPhonenumber());
    					//System.out.println((r1.getAffordableHousesData()).getManagementcompany());

   				 }

//        		 }*/
    			 model.addAttribute("list", houses_results);
    			 //return "results/affordablehouses";
                 break;
    		 }
    	return "results";}
    }
    
    
    @GetMapping(value = "/login")
    public String login() {
        return "users/login";
    }

    //Home Page
    @RequestMapping(value = {"/", "/index"})
    public String home() {
        return "index";
    }

    //Insert or Update Incidents
    @GetMapping(value = "/incidents/insert")
    public String insertOrUpdateIncident(Model model) {
        model.addAttribute("incidentreport", new Incidents());
        return "/reports/incidents";
    }

    @PostMapping(value = "/incidents/insert")
    public String insertOrUpdateIncident(@ModelAttribute Incidents incidents, Model model) {
        Incidents i = modelToObject.convert(incidents);
        incidentsRepository.save(i);
        return "redirect:/";
    }

    //Insert or Update Affordable Houses
    @GetMapping(value = "/affordablehouses/insert")
    public String insertOrUpdateAffordableHouses(Model model) {
        model.addAttribute("affordablehousesform", new AffordableHousesForm());
        return "/reports/affordablehouses";
    }

    @PostMapping(value = "/affordablehouses/insert")
    public String insertOrUpdateAffordableHouses(@ModelAttribute AffordableHousesForm affordableHousesForm, Model model) {
        AffordableHouses affordableHouses = modelToObject.convert(affordableHousesForm);
        affordableHouses.setType("Affordable Houses");
        incidentsRepository.save(affordableHouses);
        return "redirect:/";
    }

    //Insert or Update Bike Racks
    @GetMapping(value = "/bikeracks/insert")
    public String insertOrUpdateBikeRacks(Model model) {
        model.addAttribute("bikeracksform", new BikeRacks());
        return "/reports/bikeracks";
    }

    @PostMapping(value = "/bikeracks/insert")
    public String insertOrUpdateBikeRacks(@ModelAttribute BikeRacks bikeRacks, Model model) {
        BikeRacks b = modelToObject.convert(bikeRacks);
        b.setType("Bike Racks");
        incidentsRepository.save(b);
        return "redirect:/";
    }

    //Insert or Update Crash
    @GetMapping(value = "/crashes/insert")
    public String insertOrUpdateCrashes(Model model) {
        model.addAttribute("crashesform", new CrashesForm());
        return "/reports/crashes";
    }

    @PostMapping(value = "/crashes/insert")
    public String insertOrUpdateCrashes(@ModelAttribute CrashesForm crashesForm, Model model) {
        Crashes crashes = modelToObject.convert(crashesForm);
        crashes.setType("Crashes");
        incidentsRepository.save(crashes);
        return "redirect:/";
    }

    //Insert or Update Crime
    @GetMapping(value = "/crimes/insert")
    public String insertOrUpdateCrimes(Model model) {
        model.addAttribute("crimesform", new CrimesForm());
        return "/reports/crimes";
    }

    @PostMapping(value = "/crimes/insert")
    public String insertOrUpdateCrimes(@ModelAttribute CrimesForm crimesForm, Model model) {
        Crimes crimes = modelToObject.convert(crimesForm);
        crimes.setType("Crimes");
        incidentsRepository.save(crimes);
        return "redirect:/";
    }

    //Insert or Update Daily Traffic
    @GetMapping(value = "/dailytraffic/insert")
    public String insertOrUpdateDailyTraffic(Model model) {
        model.addAttribute("dailytrafficform", new DailyTrafficForm());
        return "/reports/dailytraffic";
    }

    @PostMapping(value = "/dailytraffic/insert")
    public String insertOrUpdateDailyTraffic(@ModelAttribute DailyTrafficForm dailyTrafficForm, Model model) {
        DailyTraffic dailyTraffic = modelToObject.convert(dailyTrafficForm);
        dailyTraffic.setType("Daily Traffic");
        incidentsRepository.save(dailyTraffic);
        return "redirect:/";
    }

    //Insert or Update Land Inventory
    @GetMapping(value = "/landinventory/insert")
    public String insertOrUpdateLandInventory(Model model) {
        model.addAttribute("landinventoryform", new LandInventory());
        return "/reports/landinventory";
    }

    @PostMapping(value = "/landinventory/insert")
    public String insertOrUpdateLandInventory(@ModelAttribute LandInventory landInventory, Model model) {
        LandInventory l = modelToObject.convert(landInventory);
        landInventory.setType("Average Daily Traffic");
        incidentsRepository.save(l);
        return "redirect:/";
    }

    //Insert or Update Restaurants
    @GetMapping(value = "/restaurants/insert")
    public String insertOrUpdateRestaurants(Model model) {
        model.addAttribute("restaurantsform", new RestaurantsForm());
        return "/reports/restaurants";
    }

    @PostMapping(value = "/restaurants/insert")
    public String insertOrUpdateRestaurants(@ModelAttribute RestaurantsForm restaurantsForm, Model model) {
        Restaurants restaurants = modelToObject.convert(restaurantsForm);
        restaurants.setType("Restaurants");
        incidentsRepository.save(restaurants);
        return "redirect:/";
    }
}

    //IGNORE THE FOLLOWING CODE
//    @PostMapping(value = "/incidents/insert")
//    public String insertOrUpdateIncident(@ModelAttribute Incidents incidents, Model model) {
//        if (incidents.getType().equals("Abandoned Vehicle Complaint")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Garbage Cart Black Maintenance/Replacement")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Graffiti Removal")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Pothole in Street")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Rodent Baiting/Rat Complaint")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Sanitation Code Violation")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Street Light Out")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else if (incidents.getType().equals("Tree Trim")) {
//            Incidents i = modelToObject.convert(incidents);
//            incidentsRepository.save(i);
//            return "redirect:/";
//        } else {
//            model.addAttribute("incidentreport", incidents);
//            return "/reports/incidents";
//        }
//    }