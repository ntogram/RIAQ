package com.stavros.demo_example_mongodb_m151.Model.Support;

public class CrimeData {

    private String primarytype;
    private String locationdescription;

    public CrimeData(String primarytype, String locationdescription) {
        this.primarytype = primarytype;
        this.locationdescription = locationdescription;
    }

    public CrimeData() {
    }

    public String getPrimarytype() {
        return primarytype;
    }

    public void setPrimarytype(String primarytype) {
        this.primarytype = primarytype;
    }

    public String getLocationdescription() {
        return locationdescription;
    }

    public void setLocationdescription(String locationdescription) {
        this.locationdescription = locationdescription;
    }
}
