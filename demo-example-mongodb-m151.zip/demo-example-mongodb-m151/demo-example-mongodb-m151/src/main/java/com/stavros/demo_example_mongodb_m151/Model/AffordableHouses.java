package com.stavros.demo_example_mongodb_m151.Model;

import com.stavros.demo_example_mongodb_m151.Model.Support.AffordableHousesData;

public class AffordableHouses extends Incidents{

    private String communityname;
    private Integer sqfeet;
    private AffordableHousesData affordableHousesData;

    public AffordableHouses(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String communityname, Integer sqfeet, AffordableHousesData affordableHousesData) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.communityname = communityname;
        this.sqfeet = sqfeet;
        this.affordableHousesData = affordableHousesData;
    }

    public AffordableHouses() {
    }

    public String getCommunityname() {
        return communityname;
    }

    public void setCommunityname(String communityname) {
        this.communityname = communityname;
    }

    public Integer getSqfeet() {
        return sqfeet;
    }

    public void setSqfeet(Integer sqfeet) {
        this.sqfeet = sqfeet;
    }

    public AffordableHousesData getAffordableHousesData() {
        return affordableHousesData;
    }

    public void setAffordableHousesData(AffordableHousesData affordableHousesData) {
        this.affordableHousesData = affordableHousesData;
    }
}
