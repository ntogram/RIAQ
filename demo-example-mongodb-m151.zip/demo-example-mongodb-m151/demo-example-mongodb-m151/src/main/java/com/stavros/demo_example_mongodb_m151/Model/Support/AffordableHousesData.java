package com.stavros.demo_example_mongodb_m151.Model.Support;

public class AffordableHousesData {

    private String phonenumber;
    private String managementcompany;

    public AffordableHousesData(String phonenumber, String managementcompany) {
        this.phonenumber = phonenumber;
        this.managementcompany = managementcompany;
    }

    public AffordableHousesData() {
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getManagementcompany() {
        return managementcompany;
    }

    public void setManagementcompany(String managementcompany) {
        this.managementcompany = managementcompany;
    }
}
