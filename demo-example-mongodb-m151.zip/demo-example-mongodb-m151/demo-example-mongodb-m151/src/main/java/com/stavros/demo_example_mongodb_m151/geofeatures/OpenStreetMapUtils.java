package com.stavros.demo_example_mongodb_m151.geofeatures;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class OpenStreetMapUtils {
	public final static Logger log = Logger.getLogger("OpenStreeMapUtils");
	private static OpenStreetMapUtils instance = null;
    private JSONParser jsonParser;
    public OpenStreetMapUtils() {
        jsonParser = new JSONParser();
    }

   /* public static OpenStreetMapUtils getInstance() {
        if (instance == null) {
            instance = new OpenStreetMapUtils();
        }
        return instance;
    }
    */
   @Cacheable("request")
   private String getRequest(String url) throws Exception {
        System.out.println("one slow operation");
        final URL obj = new URL(url);
        final HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        //con.setRequestMethod("GET");
       con.setRequestMethod("GET");
       System .out.println(con.getResponseCode());
        if (con.getResponseCode() != 200) {
        	 System.out.println("no response");
            return null;
        }
       // System.out.println("\nEnd");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
            
        }
        in.close();

        return response.toString();
    }
    
    public JSONArray getAddressobj(String address){
    	JSONArray array = null;
    	  Map<String, Double> res;
          StringBuffer query;
          String[] split = address.split(" ");
          String queryResult = null;

          query = new StringBuffer();
          res = new HashMap<String, Double>();

          query.append("https://nominatim.openstreetmap.org/search?q=");

          if (split.length == 0) {
              return null;
          }

          for (int i = 0; i < split.length; i++) {
              query.append(split[i]);
              if (i < (split.length - 1)) {
                  query.append("+");
              }
          }
          //System.out.println("\n Start");
          query.append("&format=json&addressdetails=1");
          
          log.debug("Query:" + query);
          //System.out.println(query.toString());

          try {
              queryResult = getRequest(query.toString());
          } catch (Exception e) {
              log.error("Error when trying to get data with the following query " + query);
          }
         // System.out.println(queryResult);
          if (queryResult == null) {
              return null;
          }
          
          Object obj = JSONValue.parse(queryResult);
          log.debug("obj=" + obj);
         
          if (obj instanceof JSONArray) {
               array = (JSONArray) obj;
          }
    	  
    	  return array;
    }
    
    public ArrayList<String> SelectRegion(JSONArray arr){
    	int i=0;
    	JSONObject jsonObject ;
    	String name = null;
    	Scanner input = new Scanner(System.in);
    	System.out.println(arr.size());
    	ArrayList<String> region=new ArrayList<String>();
     	if(arr.size()>0){
    		//Menu with numbers in website
    		//System.out.println("Please select one of the matching address");
    		for(int j=0;j<arr.size();j++){
    			  jsonObject = (JSONObject) arr.get(j);
    			  name=(String) jsonObject.get("display_name");
    			  region.add(name);
    			 //System.out.println(j+") "+name);
    		}
    	}
    	return region;
    	
    }
    
    
    
          public Map<String, Double> getCoordinates(JSONArray arr,int k){
        	  Map<String, Double> res = new HashMap<String, Double>();
        	  if (arr.size() > 0) {
                  JSONObject jsonObject = (JSONObject) arr.get(k);

                  String lon = (String) jsonObject.get("lon");
                  String lat = (String) jsonObject.get("lat");
                  log.debug("lon=" + lon);
                  log.debug("lat=" + lat);
                  res.put("lon", Double.parseDouble(lon));
                  res.put("lat", Double.parseDouble(lat));

              }
        	  
        	  
        	  return res;
          }
          
          public Map<String, Double>  getBoundingbox(JSONArray arr,int k){
        	  Map<String, Double> res = new HashMap<String, Double>();
        	  if (arr.size() > 0) {
                  JSONObject jsonObject = (JSONObject) arr.get(k);
                  JSONArray bb=(JSONArray)jsonObject.get("boundingbox");
                  String b;
                  for(int i=0;i<4;i++){
                	  
                	  res.put(String.valueOf(i),Double.parseDouble((bb.get(i).toString())));
                	 
                  }
        	 
          }
        	  return res;
          }
          
          
          public String  getzipcode(JSONArray arr,int k){
        	  String postcode=null;
        	  if (arr.size() > 0) {
                  JSONObject jsonObject = (JSONObject) arr.get(k);
                  JSONObject address=(JSONObject)jsonObject.get("address");
                   postcode=(String) address.get("postcode");
                   
        	  
        	  }
        	  return postcode;
          }
    /*public Map<String, Double> getCoordinates(String address) {
        Map<String, Double> res;
        StringBuffer query;
        String[] split = address.split(" ");
        String queryResult = null;

        query = new StringBuffer();
        res = new HashMap<String, Double>();

        query.append("https://nominatim.openstreetmap.org/search?q=");

        if (split.length == 0) {
            return null;
        }

        for (int i = 0; i < split.length; i++) {
            query.append(split[i]);
            if (i < (split.length - 1)) {
                query.append("+");
            }
        }
        //System.out.println("\n Start");
        query.append("&format=json&addressdetails=1");
        
        log.debug("Query:" + query);
        //System.out.println(query.toString());

        try {
            queryResult = getRequest(query.toString());
        } catch (Exception e) {
            log.error("Error when trying to get data with the following query " + query);
        }
       // System.out.println(queryResult);
        if (queryResult == null) {
            return null;
        }
        
        Object obj = JSONValue.parse(queryResult);
        log.debug("obj=" + obj);
       
        if (obj instanceof JSONArray) {
            JSONArray array = (JSONArray) obj;
            if (array.size() > 0) {
                JSONObject jsonObject = (JSONObject) array.get(0);

                String lon = (String) jsonObject.get("lon");
                String lat = (String) jsonObject.get("lat");
                log.debug("lon=" + lon);
                log.debug("lat=" + lat);
                res.put("lon", Double.parseDouble(lon));
                res.put("lat", Double.parseDouble(lat));

            }
        }

        return res;
    }
    
    
    public Map<String, Double> getBoundingbox(String address) {
        Map<String, Double> res;
        StringBuffer query;
        String[] split = address.split(" ");
        String queryResult = null;

        query = new StringBuffer();
        res = new HashMap<String, Double>();

        query.append("https://nominatim.openstreetmap.org/search?q=");

        if (split.length == 0) {
            return null;
        }

        for (int i = 0; i < split.length; i++) {
            query.append(split[i]);
            if (i < (split.length - 1)) {
                query.append("+");
            }
        }
        //System.out.println("\n Start");
        query.append("&format=json&addressdetails=1");
        
        log.debug("Query:" + query);
        //System.out.println(query.toString());

        try {
            queryResult = getRequest(query.toString());
        } catch (Exception e) {
            log.error("Error when trying to get data with the following query " + query);
        }
       // System.out.println(queryResult);
        if (queryResult == null) {
            return null;
        }
        
        Object obj = JSONValue.parse(queryResult);
        log.debug("obj=" + obj);
       
        if (obj instanceof JSONArray) {
            JSONArray array = (JSONArray) obj;
            if (array.size() > 0) {
                JSONObject jsonObject = (JSONObject) array.get(0);

                String lon = (String) jsonObject.get("lon");
                String lat = (String) jsonObject.get("lat");
                log.debug("lon=" + lon);
                log.debug("lat=" + lat);
                res.put("lon", Double.parseDouble(lon));
                res.put("lat", Double.parseDouble(lat));

            }
        }

        return res;
    }
    */

    
}
