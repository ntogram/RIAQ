package com.stavros.demo_example_mongodb_m151.Converters;

import com.stavros.demo_example_mongodb_m151.Model.*;
import com.stavros.demo_example_mongodb_m151.Model.Forms.*;
import com.stavros.demo_example_mongodb_m151.Model.Support.*;

public class ModelToObject {

    public Restaurants convert(RestaurantsForm restaurantsForm) {
        Restaurants restaurants = new Restaurants();
        RestaurantsData restaurantsData = new RestaurantsData();

        restaurants.setDate(restaurantsForm.getDate());
        restaurants.setType(restaurantsForm.getType());
        restaurants.setZipcode(restaurantsForm.getZipcode());
        restaurants.setStreetaddress(restaurantsForm.getStreetaddress());
        restaurants.setWard(restaurantsForm.getWard());
        restaurants.setLatitude(restaurantsForm.getLatitude());
        restaurants.setLongitude(restaurantsForm.getLongitude());

        restaurantsData.setFacilitytype(restaurantsForm.getFacilitytype());
        restaurantsData.setInspectiontype(restaurantsForm.getInspectiontype());
        restaurantsData.setName(restaurantsForm.getName());
        restaurantsData.setResults(restaurantsForm.getResults());
        restaurantsData.setViolations(restaurantsForm.getViolations());

        restaurants.setRestaurantsData(restaurantsData);
        return restaurants;
    }

    public LandInventory convert(LandInventory landInventory) {
        LandInventory l = new LandInventory();

        l.setDate(landInventory.getDate());
        l.setType(landInventory.getType());
        l.setZipcode(landInventory.getZipcode());
        l.setStreetaddress(landInventory.getStreetaddress());
        l.setWard(landInventory.getWard());
        l.setLatitude(landInventory.getLatitude());
        l.setLongitude(landInventory.getLongitude());

        l.setSqfeet(landInventory.getSqfeet());
        l.setPropertystatus(landInventory.getPropertystatus());

        return l;
    }

    public DailyTraffic convert(DailyTrafficForm dailyTrafficForm) {
        DailyTraffic dailyTraffic = new DailyTraffic();
        DailyTrafficData dailyTrafficData = new DailyTrafficData();

        dailyTraffic.setDate(dailyTrafficForm.getDate());
        dailyTraffic.setType(dailyTrafficForm.getType());
        dailyTraffic.setZipcode(dailyTrafficForm.getZipcode());
        dailyTraffic.setStreetaddress(dailyTrafficForm.getStreetaddress());
        dailyTraffic.setWard(dailyTrafficForm.getWard());
        dailyTraffic.setLatitude(dailyTrafficForm.getLatitude());
        dailyTraffic.setLongitude(dailyTrafficForm.getLongitude());

        dailyTrafficData.setVehicledirection(dailyTrafficForm.getVehicledirection());
        dailyTrafficData.setVehiclenumber(dailyTrafficForm.getVehiclenumber());

        dailyTraffic.setDailyTrafficData(dailyTrafficData);
        return dailyTraffic;
    }

    public Crimes convert(CrimesForm crimesForm) {
        Crimes crimes = new Crimes();
        CrimeData crimeData = new CrimeData();

        crimes.setDate(crimesForm.getDate());
        crimes.setType(crimesForm.getType());
        crimes.setZipcode(crimesForm.getZipcode());
        crimes.setStreetaddress(crimesForm.getStreetaddress());
        crimes.setWard(crimesForm.getWard());
        crimes.setLatitude(crimesForm.getLatitude());
        crimes.setLongitude(crimesForm.getLongitude());

        crimeData.setLocationdescription(crimesForm.getLocationdescription());
        crimeData.setPrimarytype(crimesForm.getPrimarytype());

        crimes.setCrimeData(crimeData);
        return crimes;
    }

    public Crashes convert(CrashesForm crashesForm) {
        Crashes crashes = new Crashes();
        CrashData crashData = new CrashData();

        crashes.setDate(crashesForm.getDate());
        crashes.setType(crashesForm.getType());
        crashes.setZipcode(crashesForm.getZipcode());
        crashes.setStreetaddress(crashesForm.getStreetaddress());
        crashes.setWard(crashesForm.getWard());
        crashes.setLatitude(crashesForm.getLatitude());
        crashes.setLongitude(crashesForm.getLongitude());

        crashData.setCrashtype(crashesForm.getCrashtype());
        crashData.setLightingcondition(crashesForm.getLightingcondition());
        crashData.setTime(crashesForm.getTime());
        crashData.setWeathercondition(crashesForm.getWeathercondition());

        crashes.setCrashData(crashData);
        return crashes;
    }

    public BikeRacks convert(BikeRacks bikeRacks) {
        BikeRacks b = new BikeRacks();

        b.setDate(bikeRacks.getDate());
        b.setType(bikeRacks.getType());
        b.setZipcode(bikeRacks.getZipcode());
        b.setStreetaddress(bikeRacks.getStreetaddress());
        b.setWard(bikeRacks.getWard());
        b.setLatitude(bikeRacks.getLatitude());
        b.setLongitude(bikeRacks.getLongitude());

        b.setCommunityname(bikeRacks.getCommunityname());

        return b;
    }

    public AffordableHouses convert(AffordableHousesForm affordableHousesForm) {
        AffordableHouses affordableHouses = new AffordableHouses();
        AffordableHousesData affordableHousesData = new AffordableHousesData();

        affordableHouses.setDate(affordableHousesForm.getDate());
        affordableHouses.setType(affordableHousesForm.getType());
        affordableHouses.setZipcode(affordableHousesForm.getZipcode());
        affordableHouses.setStreetaddress(affordableHousesForm.getStreetaddress());
        affordableHouses.setWard(affordableHousesForm.getWard());
        affordableHouses.setLatitude(affordableHousesForm.getLatitude());
        affordableHouses.setLongitude(affordableHousesForm.getLongitude());
        affordableHouses.setCommunityname(affordableHousesForm.getCommunityname());
        affordableHouses.setSqfeet(affordableHousesForm.getSqfeet());

        affordableHousesData.setPhonenumber(affordableHousesForm.getPhonenumber());
        affordableHousesData.setManagementcompany(affordableHousesForm.getManagementcompany());

        affordableHouses.setAffordableHousesData(affordableHousesData);
        return affordableHouses;
    }

    public Incidents convert(Incidents incidents) {
        Incidents i = new Incidents();

        i.setDate(incidents.getDate());
        i.setType(incidents.getType());
        i.setZipcode(incidents.getZipcode());
        i.setStreetaddress(incidents.getStreetaddress());
        i.setWard(incidents.getWard());
        i.setLatitude(incidents.getLatitude());
        i.setLongitude(incidents.getLongitude());
        return i;
    }
}
