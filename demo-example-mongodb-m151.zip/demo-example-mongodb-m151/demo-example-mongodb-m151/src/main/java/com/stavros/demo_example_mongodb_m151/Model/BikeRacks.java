package com.stavros.demo_example_mongodb_m151.Model;

public class BikeRacks extends Incidents {

    private String communityname;

    public BikeRacks(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String communityname) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.communityname = communityname;
    }

    public BikeRacks() {
    }

    public String getCommunityname() {
        return communityname;
    }

    public void setCommunityname(String communityname) {
        this.communityname = communityname;
    }
}
