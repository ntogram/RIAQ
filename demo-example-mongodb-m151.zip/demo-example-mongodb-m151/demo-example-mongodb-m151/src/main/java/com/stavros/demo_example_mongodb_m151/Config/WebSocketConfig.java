package com.stavros.demo_example_mongodb_m151.Config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
//enable  WebSocket server
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig extends AbstractWebSocketMessageBrokerConfigurer {
//register a websocket endpoint  that  are used by clents  for their connection to websocket server
  @Override
  public void registerStompEndpoints(StompEndpointRegistry registry) {
	//Stomp->Simple Text Oriented Messaging Protocol that defines the format and rules for data exchange
	// add s�me features that socket does not have such as send message to particular user
    registry.addEndpoint("/ws").withSockJS();//fallback for browser not support sockets
  }
//route message from one client to another
  @Override
  public void configureMessageBroker(MessageBrokerRegistry registry) {
    registry.setApplicationDestinationPrefixes("/app");//routed to message-handling methods 
    registry.enableSimpleBroker("/channel");// routed to the message broker
  //Message broker broadcasts messages to all the connected clients who are subscribed to a particular topic
  }
}
