package com.stavros.demo_example_mongodb_m151;

import com.stavros.demo_example_mongodb_m151.Model.Users.Role;
import com.stavros.demo_example_mongodb_m151.Repository.Users.RoleRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
/*

@EnableAutoConfiguration(exclude = {
		 ErrorMvcAutoConfiguration.class
		})*/
@SpringBootApplication
@EnableCaching
public class DemoExampleMongodbM151Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoExampleMongodbM151Application.class, args);
	}

	@Bean
	CommandLineRunner init(RoleRepository roleRepository) {

		return args -> {

			Role adminRole = roleRepository.findByRole("ADMIN");
			if (adminRole == null) {
				Role newAdminRole = new Role();
				newAdminRole.setRole("ADMIN");
				roleRepository.save(newAdminRole);
			}

			Role userRole = roleRepository.findByRole("USER");
			if (userRole == null) {
				Role newUserRole = new Role();
				newUserRole.setRole("USER");
				roleRepository.save(newUserRole);
			}
		};
	}
}