package com.stavros.demo_example_mongodb_m151.Model;

import org.springframework.data.annotation.Id;

import java.util.List;

public class InfoResult2 {
	
	  private String communityname;
	  private String streetaddress;
	  private int   count;
	  private List<InfoResult2> list;

	public InfoResult2() {
	}

	public String getCommunityname() {
		return communityname;
	}
	public void setCommunityname(String communityname) {
		this.communityname = communityname;
	}
	public String getStreetaddress() {
		return streetaddress;
	}
	public void setStreetaddress(String streetaddress) {
		this.streetaddress = streetaddress;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

	public List<InfoResult2> getList() {
		return list;
	}

	public void setList(List<InfoResult2> list) {
		this.list = list;
	}
}
