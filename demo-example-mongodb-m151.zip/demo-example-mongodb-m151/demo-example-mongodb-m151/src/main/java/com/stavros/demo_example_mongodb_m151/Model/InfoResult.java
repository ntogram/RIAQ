package com.stavros.demo_example_mongodb_m151.Model;

import org.springframework.data.annotation.Id;

import java.util.List;

public class InfoResult {
	@Id
	private String type;
	private int count;
	private List<InfoResult> list;

	public InfoResult() {
	}

	public String getName() {
		return type;
	}

	public String getType() {
		return type;
	}

	public void setName(String type) {
		this.type = type;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<InfoResult> getList() {
		return list;
	}

	public void setList(List<InfoResult> list) {
		this.list = list;
	}
}
