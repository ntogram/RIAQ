package com.stavros.demo_example_mongodb_m151.Model;

public class LandInventory extends Incidents {

    private String propertystatus;

    private Integer sqfeet;

    public LandInventory(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String propertystatus) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.propertystatus = propertystatus;
       
    }

    public LandInventory() {
    }

    public String getPropertystatus() {
        return propertystatus;
    }

    public void setPropertystatus(String propertystatus) {
        this.propertystatus = propertystatus;
    }

    public Integer getSqfeet() {
        return sqfeet;
    }

    public void setSqfeet(Integer sqfeet) {
        this.sqfeet = sqfeet;
    }
}
