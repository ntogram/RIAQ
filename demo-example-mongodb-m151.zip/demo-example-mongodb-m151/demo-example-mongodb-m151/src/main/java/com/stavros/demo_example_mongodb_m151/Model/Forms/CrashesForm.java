package com.stavros.demo_example_mongodb_m151.Model.Forms;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;

public class CrashesForm extends Incidents {

    private String time;
    private String weathercondition;
    private String lightingcondition;
    private String crashtype;

    public CrashesForm(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, String time, String weathercondition, String lightingcondition, String crashtype) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.time = time;
        this.weathercondition = weathercondition;
        this.lightingcondition = lightingcondition;
        this.crashtype = crashtype;
    }

    public CrashesForm() {
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getWeathercondition() {
        return weathercondition;
    }

    public void setWeathercondition(String weathercondition) {
        this.weathercondition = weathercondition;
    }

    public String getLightingcondition() {
        return lightingcondition;
    }

    public void setLightingcondition(String lightingcondition) {
        this.lightingcondition = lightingcondition;
    }

    public String getCrashtype() {
        return crashtype;
    }

    public void setCrashtype(String crashtype) {
        this.crashtype = crashtype;
    }
}
