package com.stavros.demo_example_mongodb_m151.Model;

import java.util.List;

public class InfoResult3 {

	private String	inspectiontype; 
	private String	results;
	private String	violations;
	private String	name;
	private String	facilitytype;
	private String streetaddress;
	private List<InfoResult3> list;

	public InfoResult3() {
	}

	public String getInspectiontype() {
		return inspectiontype;
	}
	public void setInspectiontype(String inspectiontype) {
		this.inspectiontype = inspectiontype;
	}
	public String getResults() {
		return results;
	}
	public void setResults(String results) {
		this.results = results;
	}
	public String getViolations() {
		return violations;
	}
	public void setViolations(String violations) {
		this.violations = violations;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFacilitytype() {
		return facilitytype;
	}
	public void setFacilitytype(String facilitytype) {
		this.facilitytype = facilitytype;
	}
	public String getStreetaddress() {
		return streetaddress;
	}
	public void setStreetaddress(String streetaddress) {
		this.streetaddress = streetaddress;
	}

	public List<InfoResult3> getList() {
		return list;
	}

	public void setList(List<InfoResult3> list) {
		this.list = list;
	}
}
