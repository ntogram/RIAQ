package com.stavros.demo_example_mongodb_m151.Model;

import com.stavros.demo_example_mongodb_m151.Model.Support.CrimeData;

public class Crimes extends Incidents {

    private CrimeData crimeData;

    public Crimes(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, CrimeData crimeData) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.crimeData = crimeData;
    }

    public Crimes() {
    }

    public CrimeData getCrimeData() {
        return crimeData;
    }

    public void setCrimeData(CrimeData crimeData) {
        this.crimeData = crimeData;
    }
}
