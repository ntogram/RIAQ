package com.stavros.demo_example_mongodb_m151.Model;

import com.stavros.demo_example_mongodb_m151.Model.Support.CrashData;

public class Crashes extends Incidents {

    private CrashData crashData;

    public Crashes(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, CrashData crashData) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.crashData = crashData;
    }

    public Crashes() {
    }

    public CrashData getCrashData() {
        return crashData;
    }

    public void setCrashData(CrashData crashData) {
        this.crashData = crashData;
    }
}
