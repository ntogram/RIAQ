package com.stavros.demo_example_mongodb_m151.Repository.Users;

import com.stavros.demo_example_mongodb_m151.Model.Users.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepository extends MongoRepository<User, String> {
    User findByEmail(String email);
}
