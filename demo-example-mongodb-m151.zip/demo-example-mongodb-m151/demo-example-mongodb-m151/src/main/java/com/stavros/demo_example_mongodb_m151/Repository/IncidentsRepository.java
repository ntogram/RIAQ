package com.stavros.demo_example_mongodb_m151.Repository;

import com.stavros.demo_example_mongodb_m151.Model.Incidents;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentsRepository extends MongoRepository<Incidents, String>,QueryRepository {

    Incidents findByid(String id);
}
