package com.stavros.demo_example_mongodb_m151.Model;

import com.stavros.demo_example_mongodb_m151.Model.Support.RestaurantsData;

public class Restaurants extends Incidents{

    private RestaurantsData restaurantsData;

    public Restaurants(String id, String date, String type, Integer zipcode, String streetaddress, Integer ward, Double latitude, Double longitude, RestaurantsData restaurantsData) {
        super(id, date, type, zipcode, streetaddress, ward, latitude, longitude);
        this.restaurantsData = restaurantsData;
    }

    public Restaurants() {
    }

    public RestaurantsData getRestaurantsData() {
        return restaurantsData;
    }

    public void setRestaurantsData(RestaurantsData restaurantsData) {
        this.restaurantsData = restaurantsData;
    }
}
