package com.stavros.demo_example_mongodb_m151.Config;

import org.springframework.security.core.Authentication;

public interface IAuthenticationFacade {

	
	Authentication getAuthentication();
	
	
}
