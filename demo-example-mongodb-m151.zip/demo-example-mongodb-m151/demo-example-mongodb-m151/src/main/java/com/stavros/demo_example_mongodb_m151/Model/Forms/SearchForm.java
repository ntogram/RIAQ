package com.stavros.demo_example_mongodb_m151.Model.Forms;

import java.util.ArrayList;

public class SearchForm {
private String address;
private String type;
private String bottom_area_bound;
private String upper_area_bound;
private ArrayList<String> available_addresses;

public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getBottom_area_bound() {
	return bottom_area_bound;
}
public void setBottom_area_bound(String bottom_area_bound) {
	this.bottom_area_bound = bottom_area_bound;
}
public String getUpper_area_bound() {
	return upper_area_bound;
}
public void setUpper_area_bound(String upper_area_bound) {
	this.upper_area_bound = upper_area_bound;
}
public ArrayList<String> getAvailable_addresses() {
	return available_addresses;
}
public void setAvailable_addresses(ArrayList<String> available_addresses) {
	this.available_addresses = available_addresses;
}


public String get_correct_type(){
	 String correct_type = this.type;
	 String[] parts = this.type.split("_");
	 if(parts.length==2){
		 correct_type=parts[0]+" "+parts[1];
		
	 }
	 
	 
	 
	return correct_type;
}

}
