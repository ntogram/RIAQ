package com.stavros.demo_example_mongodb_m151.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.stavros.demo_example_mongodb_m151.Model.AffordableHouses;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult2;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult3;
import com.stavros.demo_example_mongodb_m151.Model.InfoResult4;
import com.stavros.demo_example_mongodb_m151.Model.LandInventory;

import com.stavros.demo_example_mongodb_m151.Model.Forms.AffordableHousesForm;

public interface QueryRepository {

	List<InfoResult> group_incidents(String classtype,ArrayList<Double> blat,ArrayList<Double> blon);
	List<InfoResult> group_crimes(ArrayList<Double> blat,ArrayList<Double> blon);
	List<InfoResult2> group_bikeracks(ArrayList<Double> blat,ArrayList<Double> blon);
	List<InfoResult3> get_close_restaurants(ArrayList<Double> blat,ArrayList<Double> blon);
	List<InfoResult4> get_points_with_more_dailytraffic(ArrayList<Double> blat,ArrayList<Double> blon);
	List<List<InfoResult>> getcrash_info(ArrayList<Double> blat,ArrayList<Double> blon);
	List<LandInventory> get_land(ArrayList<Double> blat,ArrayList<Double> blon);
	List<AffordableHouses> get_houses(ArrayList<Double> blat,ArrayList<Double> blon,Integer lb,Integer ub);
	List<InfoResult> group_all_incidents_by_zip();
}
