function ShowForm(){
		var address_object = document.getElementById("available address").value;
		if (address_object) {
			
			document.getElementById("searchForm").style.display = "inline"; 
			document.getElementById("address").value=address_object;
			
		}
	
	var type_object = document.getElementById("type").value;
		  //alert(type_object)
		  if(type_object=='Affordable_Houses'){
			  document.getElementById("boundaries_area").style.display = "inline"; 
			  
			  
			  
		  }
	
	
	
}

function back(){
	document.getElementById("searchForm").reset(); 
	document.getElementById("boundaries_area").style.display = "none";
	window.location.replace("http://localhost:8080/");
}
