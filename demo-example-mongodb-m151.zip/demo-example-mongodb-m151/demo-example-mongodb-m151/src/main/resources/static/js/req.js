function  getenecessaryattrs(){
	var type_par=document.getElementById("type").textContent;
	var house_check=type_par.includes("Affordable_Houses")
	if(house_check==true){
		document.getElementById("boundaries_area").style.display = "inline"; 
	}
	var type = type_par.split(" ");
	var tableval=document.getElementsByClassName("table table-striped");
	
	
	
	
	document.getElementById(type[1]).style.display='inline';
	var types=["Incidents","Crimes","Crashes","Bike_Racks","Affordable_Houses","Daily_Traffic","Restaurants","Land_Inventory"];
	var offset=2
	for (i = 0; i < types.length; i++) {
			j=i;
		if(i>2){
			j=i+offset;
		}
		
		
		
		if(types[i]!=type[1]){
			document.getElementById(types[i]).style.display='none';
		}
		else{
			var count=tableval[j].rows.length;
			//alert(count)
			if(count==1){
				document.getElementById(types[i]).style.display='none';
				document.getElementById("non").style.display='inline';
			}
			
		}
	}
	
	
	
};

function display_query(){
	 var query_type = document.getElementById("crash_query").value
	 document.getElementById(query_type).style.display='inline';
	 var types=["Weather_Conditions","Lightning_Conditions","Crash_Type"];
		for (i = 0; i < types.length; i++) {
			if(types[i]!=query_type){
				document.getElementById(types[i]).style.display='none';
			}
		}
		
	 
	 
	 
	 
}