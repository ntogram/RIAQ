﻿function display_house_bounds() {
          var type_object = document.getElementById("type").value;
		  //alert(type_object)
		  if(type_object=='Affordable_Houses'){
			  document.getElementById("boundaries_area").style.display = "inline"; 
			  document.getElementById("above_boundary").value=600;
			  document.getElementById("bottom_boundary").value=1;
			  
			  
		  }
		  else{
			  document.getElementById("boundaries_area").style.display = "none"; 
		  }
};


function check_houses_bounds(){
	var upper_bound =parseInt( document.getElementById("above_boundary").value);
	var low_bound = parseInt(document.getElementById("bottom_boundary").value);
	var check=(upper_bound<low_bound);
	
	
	if(check==true){
		
		document.getElementById("above_boundary").style.borderColor = "red"; 
		document.getElementById("bottom_boundary").style.borderColor = "red"; 
		return false;
	}
	else{
		document.getElementById("above_boundary").style.borderColor = "initial"; 
		document.getElementById("bottom_boundary").style.borderColor = "initial"; 
		return true;
	}
	
	
	
	
	
	
};

	function check_form(){
		var bounds_level=check_houses_bounds();
		//alert(bounds_level)
		return bounds_level;
	}
	
function back(){
	document.getElementById("searchForm").reset(); 
	document.getElementById("boundaries_area").style.display = "none";
	window.location.replace("http://localhost:8080/");
}