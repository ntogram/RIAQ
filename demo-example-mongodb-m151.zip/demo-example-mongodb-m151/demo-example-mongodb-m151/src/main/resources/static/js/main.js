'use strict';

var nameInput = $('#name');

var roomInput = $('#room-id');
var croomInput = $('#room-id1');
var usernamePage = document.querySelector('#username-page');
var chatPage = document.querySelector('#chat-page');
var usernameForm = document.querySelector('#usernameForm');
var messageForm = document.querySelector('#messageForm');
var messageInput = document.querySelector('#message');
var messageArea = document.querySelector('#messageArea');
var connectingElement = document.querySelector('.connecting');
var roomIdDisplay = document.querySelector('#room-id-display');
var change_room=document.querySelector('#btn_ok');
var logoff=document.querySelector('#btn_logoff');
var stompClient = null;
var currentSubscription;
var username = null;
var roomId = null;
var topic = null;

var colors = [
    '#2196F3', '#32c787', '#00BCD4', '#ff5652',
    '#ffc107', '#ff85af', '#FF9800', '#39bbb0'
];

function connect(event) {
  
  username = nameInput.val().trim();
  roomId=roomInput .val()
  Cookies.set('name', username);
  Cookies.set(username, roomId);
  
  
  
  
  if (username) {
    usernamePage.classList.add('hidden');
    chatPage.classList.remove('hidden');
    croomInput.val("Incidents");
    var socket = new SockJS('/ws');
    stompClient = Stomp.over(socket);

    stompClient.connect({}, onConnected, onError);
  }
  event.preventDefault();
}

// Leave the current room and enter a new one.
function enterRoom(newRoomId) {
  roomId = newRoomId;
  
  Cookies.set(username, roomId);
  roomIdDisplay.textContent = roomId;
  topic = `/app/chat/${newRoomId}`;

  if (currentSubscription) {
    currentSubscription.unsubscribe();
  }
  currentSubscription = stompClient.subscribe(`/channel/${roomId}`, onMessageReceived);

  stompClient.send(`${topic}/addUser`,
    {},
    JSON.stringify({sender: username, type: 'JOIN'})
  );
  
  
}


function logout(){
	if (currentSubscription) {
	    currentSubscription.unsubscribe();
	  }
	usernamePage.classList.remove('hidden');
	chatPage.classList.add('hidden');
	messageArea.innerHTML = "";
	roomInput.val("Incidents");
	stompClient.send(`${topic}/RemoveUser`,
    {},window.location.replace("http://localhost:8080/"));
	/*stompClient.send(`${topic}/RemoveUser`,
    {},
    JSON.stringify({sender: username, type: 'LEAVE'})
  );*/
	//alert(logoff);*/
	

//window.location.replace("http://localhost:8080/");


	//alert("Alex");
}
function onConnected() {
  enterRoom(roomInput.val());
  connectingElement.classList.add('hidden');
}

function onError(error) {
  connectingElement.textContent = 'Could not connect to WebSocket server. Please refresh this page to try again!';
  connectingElement.style.color = 'red';
}



function ChangeRoom(event){
	//var current_room=roomInput.val();
	
	var  current_room=Cookies.get(username);
	 var new_roominput=$('#room-id1');
	  var new_room=new_roominput.val();
	  var ch="1)"+current_room+", 2)"+new_room;
	  //alert(ch)
	  if(new_room!=current_room){
		  enterRoom(new_room);
		  while (messageArea.firstChild) {
		      messageArea.removeChild(messageArea.firstChild);
		    }
		 current_room=new_room;
		 
	  }
//alert(ch);
}


function back(){
	usernameForm.reset(); 
	window.location.replace("http://localhost:8080/");
}





function sendMessage(event) {
  var messageContent = messageInput.value.trim();
  if (messageContent && stompClient) {
	    var chatMessage = {
	      sender: username,
	      content: messageInput.value,
	      type: 'CHAT'
	    };
	    stompClient.send(`${topic}/sendMessage`, {}, JSON.stringify(chatMessage));
	  }
	  messageInput.value = '';
	  event.preventDefault();
  
  
  
  
  
  /*var current_room=roomInput.val();
  var new_roominput=$('#room-id1');
  var new_room=new_roominput.val();
  if(new_room!=current_room){
	  enterRoom(new_room);
	  while (messageArea.firstChild) {
	      messageArea.removeChild(messageArea.firstChild);
	    }
  }
  */
 /*
  if (messageContent.startsWith('/join ')) {
    var newRoomId = messageContent.substring('/join '.length);
    enterRoom(newRoomId);
    while (messageArea.firstChild) {
      messageArea.removeChild(messageArea.firstChild);
    }
  } else if (messageContent && stompClient) {
    var chatMessage = {
      sender: username,
      content: messageInput.value,
      type: 'CHAT'
    };
    stompClient.send(`${topic}/sendMessage`, {}, JSON.stringify(chatMessage));
  }
  messageInput.value = '';
  event.preventDefault();*/
}

function onMessageReceived(payload) {
  var message = JSON.parse(payload.body);

  var messageElement = document.createElement('li');

  if (message.type == 'JOIN') {
    messageElement.classList.add('event-message');
    message.content = message.sender + ' joined!';
  } else if (message.type == 'LEAVE') {
    messageElement.classList.add('event-message');
    message.content = message.sender + ' left!';
  } else {
    messageElement.classList.add('chat-message');

    var avatarElement = document.createElement('i');
    var avatarText = document.createTextNode(message.sender[0]);
    avatarElement.appendChild(avatarText);
    avatarElement.style['background-color'] = getAvatarColor(message.sender);

    messageElement.appendChild(avatarElement);

    var usernameElement = document.createElement('span');
    var usernameText = document.createTextNode(message.sender);
    usernameElement.appendChild(usernameText);
    messageElement.appendChild(usernameElement);
  }

  var textElement = document.createElement('p');
  var messageText = document.createTextNode(message.content);
  textElement.appendChild(messageText);

  messageElement.appendChild(textElement);

  messageArea.appendChild(messageElement);
  messageArea.scrollTop = messageArea.scrollHeight;
}

function getAvatarColor(messageSender) {
  var hash = 0;
  for (var i = 0; i < messageSender.length; i++) {
      hash = 31 * hash + messageSender.charCodeAt(i);
  }
  var index = Math.abs(hash % colors.length);
  return colors[index];
}

$(document).ready(function() {
  var savedName = Cookies.get('name');
  if (savedName) {
    //nameInput.val(savedName);?
  }

  var savedRoom = Cookies.get(username);
  if (savedRoom) {
    //roomInput.val(savedRoom);
    //alert( roomInput.val());
  }

  usernamePage.classList.remove('hidden');
  usernameForm.addEventListener('submit', connect, true);
  messageForm.addEventListener('submit', sendMessage, true);
  change_room.addEventListener("click",ChangeRoom,true);
  logoff.addEventListener("click",logout,true);
});
